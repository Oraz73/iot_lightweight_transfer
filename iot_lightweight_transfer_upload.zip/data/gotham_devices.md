# Gotham 2025 subset used

* Source: Zenodo record 14502760, `GothamDataset2025.zip` (read with HTTP range requests, `src/gotham_fetch.py`).
* Benign: all 78 per-device benign captures; captures larger than 600 MB (six camera/video devices) truncated to the first 60 MB.
* Attacks: `merlin` floods and `network-scanning` captures of the labelled devices
  `city-power-1, domotic-monitor-1, air-quality-1, combined-cycle-10` (`--attack-devices`).
  After labelling, flood traffic came from 2 devices and scanning from 4.
* Labels: per-packet labels aggregated per (device, IP pair, protocol, second) by `src/gotham_labels.py`;
  flow = attack if >= 90 % malicious packets, benign if <= 10 %, else dropped (`src/gotham_build.py`, version marker `gotham_build v2`).
  Clock offset searched over +-14 h; best offset 0 h.
* SYN vs ACK floods share one label and are separated by initiator flags (src2dst SYN share >= 50 %, ACK share < 50 %).

# Lightweight neural networks for IoT anomaly detection across networks

Code, notebooks and results for the paper
**"Comparative Analysis of Lightweight Neural Networks for Anomaly Detection in Smart City Networks:
Cross-Network Transfer and the Role of Benign-Traffic Diversity"**.

We train small detectors (MLP_S, MLP_M, CNN1D, autoencoder, decision tree) on one of three IoT testbeds
(CIC-IoT-2023, Edge-IIoTset, Gotham 2025) and test them on the other two. All flows are re-extracted
from raw PCAPs with one tool (NFStream 6.6). Main findings: in-domain F1 does not predict cross-network
F1; full INT8 is safe on average for MLPs; timing-feature encoding has no detectable effect; the
diversity of benign training traffic reduces cross-network false alarms about twice as strongly as its
volume; a few devices' worth of unlabelled local benign traffic removes most remaining false alarms.

## Open in Colab

Clean notebooks (run them in order):

| Step | Notebook |
|---|---|
| 1 | [01_extract_cic_edge](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/notebooks/01_extract_cic_edge.ipynb) |
| 2 | [02_gotham_and_common_classes](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/notebooks/02_gotham_and_common_classes.ipynb) |
| 3 | [03_E2_timing_features](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/notebooks/03_E2_timing_features.ipynb) |
| 4 | [04_E3_benign_diversity](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/notebooks/04_E3_benign_diversity.ipynb) |
| 5 | [05_E3b_E4_controls](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/notebooks/05_E3b_E4_controls.ipynb) |
| 6 | [06_E1_lightweight_models](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/notebooks/06_E1_lightweight_models.ipynb) |

Executed notebooks of the original runs, with all outputs:
[v4a](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/logs/v4a_gotham_rebuild_E2_E3_part1.ipynb) ·
[v4b](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/logs/v4b_gotham_E2_E3_part2_reports.ipynb) ·
[v5](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/logs/v5_E3b_E4_controls.ipynb) ·
[v6](https://colab.research.google.com/github/Oraz73/iot_lightweight_transfer/blob/main/logs/v6_E1_models.ipynb)

## Repository layout

```
src/            the exact scripts that produced the paper results (comments are in Russian)
notebooks/      clean Colab notebooks, one per step (01-06), no outputs
logs/           the executed notebooks of the original runs, with outputs (evidence)
  exploratory/  earlier two-dataset runs cited in the paper as exploratory
results/        result tables behind every number and figure in the paper
data/           PCAP manifest with attacker/victim addresses, Gotham subset description
paper/          LaTeX sources (paper6.tex = 6-page version, paper.tex = full version) and make_figs.py
tools/          hash_pcaps.py (provenance), make_notebooks.py (regenerates notebooks/)
```

## How to reproduce

Everything runs on a free Google Colab CPU runtime. Put this repository on Google Drive as
`MyDrive/iot_lightweight_transfer` (or edit `REPO` in the first cell of each notebook). Data and
results go to `MyDrive/iot_experiment/work`.

| Step | Notebook | Produces | Paper | Approx. time |
|---|---|---|---|---|
| 1 | `01_extract_cic_edge` | `data/features_{CICIoT2023,EdgeIIoT}.parquet` | §III-A/B | 30–60 min |
| 2 | `02_gotham_and_common_classes` | `data/features_Gotham.parquet`, `data3/` | §III-A/B | 30–60 min |
| 3 | `03_E2_timing_features` | `results3/` | E2, Tables E2 | 1–2 h |
| 4 | `04_E3_benign_diversity` | `results_diversity3/` | E3, Fig. E3 | 1–2 h |
| 5 | `05_E3b_E4_controls` | `results_v5/` | E3b, E4, mixed models | 1–2 h |
| 6 | `06_E1_lightweight_models` | `results_v6/` | E1, Table E1 | ~30 min |
| 7 | `python paper/make_figs.py` | `paper/figs/` | all figures | seconds |

Every script checkpoints after each block, so an interrupted Colab session can simply be re-run.

**Data access.** CIC-IoT-2023 requires registration at UNB CIC; download the PCAPs listed in
`data/manifest_cic_edge.csv` into `work/pcaps/cic/`. Edge-IIoTset is fetched from Kaggle
(`mohamedamineferrag/edgeiiotset-cyber-security-dataset-of-iot-iiot`, needs your own `kaggle.json`;
never commit it). Gotham 2025 is read directly from Zenodo record 14502760.

## Settings

| Item | Value |
|---|---|
| Seeds | 0, 1, 2 (split, sampling, model initialisation) |
| Split | 70/30 stratified by class; scaler fitted on source training data only |
| Flow export | NFStream 6.6, bidirectional, idle 30 s, active 10 s; ≤ 50,000 flows per capture, sampled at random (seeded) |
| Trimming | first 3M packets per capture; CIC SYN and Edge SYN/UDP/ICMP floods: first 400k packets; Gotham captures > 600 MB: first 60 MB |
| Metric | F1 with sample weights giving 10 % attack prevalence; false-alarm and detection rates unweighted |
| E1 | Keras; Adam lr 1e-3, batch 256, ≤ 30 epochs, early stopping (patience 3); 15 % of training data held out for the AE threshold / checks, 10 % of the rest for early stopping; 10,000 flows per class (or all available); INT8 PTQ calibrated on 500 training flows |
| E2 | scikit-learn: DT depth 10; MLP (16,8), (64,32); AE MLPRegressor (16,4,16), threshold = 99th percentile of benign validation error; `max_iter=200`, early stopping; up to 30,000 flows per class (all available if fewer) |
| E3 | DT and MLP_S; 5,000 benign + 5,000 attack flows; k = 1, 2, 4, 8, …, all; ≤ 4 random combinations per k; groups need ≥ 100 benign flows (CIC hosts in 192.168.137.0/24) |
| E3b / E4 | ≤ 3 combinations per cell; E4 replaces 1,000 of 5,000 source benign flows with 1000/k_t flows from each of k_t target devices |
| Statistics (primary) | per-direction slopes or mean differences, tested over transfer directions (bootstrap 95 % CI with 10,000 resamples of directions, one-sample t-test, sign test); TOST equivalence test for E2 (margin ±0.05 F1); script `tools/robust_stats.py`, output `results/robust_direction_level.csv` |
| Statistics (secondary) | Wilcoxon signed-rank (`zero_method="zsplit"`) with Holm correction; bootstrap CIs with 5,000 resamples; linear mixed models (statsmodels MixedLM, REML, model type as fixed effect, random intercept per transfer direction) |
| Software | Python 3.13, NFStream 6.6.0, TensorFlow 2.21.0; other versions in `requirements.txt` |

## Known deviations and limits of reproducibility

* **Partial CIC-IoT-2023 downloads.** In the original run the CIC DDoS flood captures were partial
  browser downloads; only their first 3M (SYN: 400k) packets were used. A full download gives the same
  result only if its first packets are identical. Compare your trimmed files with the hashes produced by
  `tools/hash_pcaps.py` (the notebooks write them to `work/pcap_hashes_*.csv`); reference hashes of the
  original run are listed in `data/` when available.
* **TensorFlow on CPU is not bit-for-bit deterministic.** Expect E1 numbers to differ slightly from
  `results/E1_models`, within the reported confidence intervals.
* **Logs of E2/E3 are split.** The final E2/E3 run was executed in two Colab sessions
  (`logs/v4a_*`, `logs/v4b_*`); the second session reused checkpointed results.
* Script comments and printed messages are in Russian; the logic is unchanged from the runs in `logs/`.

## Results files

| File | Content |
|---|---|
| `results/E1_models/T1_in_vs_cross.csv` | in-domain vs cross-network F1, CIs, false alarms, detection per model and precision |
| `results/E1_models/T2_quantization_cost.csv` | INT8 − fp32 F1, CI, worst case, Wilcoxon p |
| `results/E1_models/T3_resources.csv` | parameters, TFLite size, CPU latency |
| `results/E2_timing/contrasts_f1_prev0.1.csv` | feature-set contrasts (Table E2) |
| `results/E2_timing/summary_f1_prev0.1.csv` | F1 per model and feature set |
| `results/E2_timing/shift_ks_per_group.csv` | mean KS shift between datasets per feature group |
| `results/E2_timing/resource_estimate.csv` | analytic state/operation estimate per feature set |
| `results/E3_diversity/diversity_results.csv` | every E3 run |
| `results/E3b_E4_controls/A_means.csv`, `B_means.csv` | cell means for E3b and E4 |
| `results/E3b_E4_controls/mixed_models.csv` | mixed-model estimates (secondary; p-values overstate evidence) |
| `results/robust_direction_level.csv` | primary direction-level tests for E2, E3, E3b, E4 |
| `results/E2_timing/results.csv`, `results/E3b_E4_controls/volume_results.csv`, `adapt_results.csv` | per-run results |

Per-run files for E1 (`v6_results.csv`) and per-label results (`per_label.csv`) are produced by the notebooks.

## Citation

See `CITATION.cff`.

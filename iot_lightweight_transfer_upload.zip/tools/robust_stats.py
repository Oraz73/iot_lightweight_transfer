"""Direction-level re-analysis of E2, E3, E3b and E4.

Runs within one transfer direction share data, seeds and group combinations, so
they are not independent. Here every transfer direction contributes one number
(a slope or a mean difference); tests and bootstrap intervals are computed over
directions. Output: results/robust_direction_level.csv and a printed summary.

usage: python tools/robust_stats.py   (from the repository root)
"""
import os

import numpy as np
import pandas as pd
from scipy import stats

R = os.path.join(os.path.dirname(__file__), "..", "results")
rng = np.random.default_rng(0)
rows = []


def boot_ci(x, n=10000):
    x = np.asarray(x, float)
    m = rng.choice(x, (n, len(x))).mean(axis=1)
    return np.percentile(m, [2.5, 97.5])


def summarize(name, s, note=""):
    s = pd.Series(s, dtype=float)
    lo, hi = boot_ci(s.values)
    t = stats.ttest_1samp(s, 0)
    neg = int((s < 0).sum())
    sign_p = stats.binomtest(neg, len(s), 0.5).pvalue
    rows.append(dict(analysis=name, n_directions=len(s), mean=s.mean(), boot_ci_low=lo,
                     boot_ci_high=hi, t_p=t.pvalue, n_negative=neg, sign_p=sign_p, note=note))


def slopes(df, y, xs, by):
    """Per-direction OLS of y on xs with the model type demeaned out."""
    out = {}
    for g, x in df.groupby(by):
        x = x.copy()
        yy = x[y] - x.groupby("model")[y].transform("mean")
        X = np.column_stack([x[c] - x.groupby("model")[c].transform("mean") for c in xs])
        out[g] = np.linalg.lstsq(X, yy.values, rcond=None)[0]
    return pd.DataFrame(out, index=xs).T


# ---------------------------------------------------------------- E3
d = pd.read_csv(f"{R}/E3_diversity/diversity_results.csv")
d = d[d.eval_on != "source"].copy()
d["log2k"] = np.log2(d.k)
s3 = slopes(d, "false_alarm", ["log2k"], ["experiment", "eval_on"])["log2k"]
summarize("E3 false_alarm ~ log2k", s3, "8 directions; Gotham[file] and Gotham[type] share data")
s3i = s3[[i for i in s3.index if i[0] != "Gotham[type]"]]
summarize("E3 false_alarm ~ log2k (independent sources only)", s3i, "6 directions, Gotham by device")

# ---------------------------------------------------------------- E3b
v = pd.read_csv(f"{R}/E3b_E4_controls/volume_results.csv")
v["log2k"], v["log2V"] = np.log2(v.k), np.log2(v.V)
sv = slopes(v, "false_alarm", ["log2k", "log2V"], ["source", "target"])
summarize("E3b false_alarm: beta log2k", sv.log2k)
summarize("E3b false_alarm: beta log2V", sv.log2V)
summarize("E3b false_alarm: beta log2k - beta log2V", sv.log2k - sv.log2V, "negative = diversity stronger")
ratio = [rng.choice(sv.index.size, sv.index.size) for _ in range(10000)]
rb = np.array([sv.log2k.values[i].mean() / sv.log2V.values[i].mean() for i in ratio])
rows.append(dict(analysis="E3b ratio mean(beta_k)/mean(beta_V)", n_directions=len(sv),
                 mean=sv.log2k.mean() / sv.log2V.mean(),
                 boot_ci_low=np.percentile(rb, 2.5), boot_ci_high=np.percentile(rb, 97.5)))

# ---------------------------------------------------------------- E4
a = pd.read_csv(f"{R}/E3b_E4_controls/adapt_results.csv")
a["log2k1"] = np.log2(a.k_t + 1)
sa = slopes(a, "false_alarm", ["log2k1"], ["source", "target"])["log2k1"]
sd = slopes(a, "detection", ["log2k1"], ["source", "target"])["log2k1"]
summarize("E4 false_alarm ~ log2(k_t+1)", sa)
summarize("E4 detection ~ log2(k_t+1)", sd, "negative = detection loss")
m = a.groupby(["source", "target", "k_t"])[["detection"]].mean().reset_index()
dd = m.groupby(["source", "target"]).apply(
    lambda x: x.loc[x.k_t.idxmax(), "detection"] - x.loc[x.k_t.idxmin(), "detection"])
summarize("E4 detection change, max k_t minus k_t=0", dd)

# ---------------------------------------------------------------- E2
e = pd.read_csv(f"{R}/E2_timing/results.csv")
e = e[(e.prevalence.astype(str) == "0.1") & (~e.in_domain.astype(bool))]
p = e.groupby(["source", "target", "model", "feature_set"]).f1.mean().unstack()
CONTR = [("FS4_base+shape", "FS2_base+raw"), ("FS2_base+raw", "FS1_base"),
         ("FS4_base+shape", "FS1_base"), ("FS3_base+rate", "FS1_base"),
         ("FS5_base+alltime", "FS4_base+shape"), ("FS6_alltime+ports", "FS5_base+alltime")]
MARGIN = 0.05
for A, B in CONTR:
    diff = (p[A] - p[B]).groupby(["source", "target"]).mean()   # 6 directions
    summarize(f"E2 {A} - {B}", diff)
    n, mu, se = len(diff), diff.mean(), diff.std(ddof=1) / np.sqrt(len(diff))
    p_tost = max(stats.t.sf((mu + MARGIN) / se, n - 1), stats.t.cdf((mu - MARGIN) / se, n - 1))
    rows[-1].update(tost_margin=MARGIN, tost_p=p_tost,
                    t90_low=mu - stats.t.ppf(0.95, n - 1) * se, t90_high=mu + stats.t.ppf(0.95, n - 1) * se)

out = pd.DataFrame(rows)
out.to_csv(f"{R}/robust_direction_level.csv", index=False)
pd.set_option("display.width", 250)
print(out.round(4).to_string(index=False))
print("\nE3 per-direction slopes:\n", s3.round(4).to_string())
print("\nE3b per-direction slopes:\n", sv.round(4).to_string())
print("\nE4 per-direction slopes (FA, detection):\n", pd.concat([sa, sd], axis=1, keys=["FA", "det"]).round(4).to_string())

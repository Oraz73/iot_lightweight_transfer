"""SHA-256, size and packet count of every PCAP in the given folders.

usage: python hash_pcaps.py DIR [DIR ...] --out hashes.csv
"""
import argparse, csv, glob, hashlib, os, subprocess

ap = argparse.ArgumentParser()
ap.add_argument("dirs", nargs="+")
ap.add_argument("--out", required=True)
a = ap.parse_args()
rows = []
for d in a.dirs:
    for p in sorted(glob.glob(os.path.join(d, "**", "*.pcap"), recursive=True)):
        h = hashlib.sha256()
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        try:
            n = subprocess.run(["tcpdump", "-r", p, "-qn"], capture_output=True, text=True).stdout.count("\n")
        except FileNotFoundError:
            n = ""
        rows.append({"file": os.path.relpath(p, os.path.dirname(d.rstrip("/"))),
                     "bytes": os.path.getsize(p), "packets": n, "sha256": h.hexdigest()})
with open(a.out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["file", "bytes", "packets", "sha256"])
    w.writeheader(); w.writerows(rows)
print(len(rows), "files ->", a.out)

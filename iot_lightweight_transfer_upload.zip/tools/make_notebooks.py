"""Generates the clean Colab notebooks in ../notebooks (no outputs).

Each notebook mounts Google Drive, uses WORK as the working directory for data
and results, and calls the scripts in ../src unchanged. Re-running a notebook
skips finished steps (the scripts checkpoint per block).
"""
import json
import os

OUT = os.path.join(os.path.dirname(__file__), "..", "notebooks")
os.makedirs(OUT, exist_ok=True)

SETUP = r'''# --- setup: edit the two paths if your layout differs ------------------------
REPO = '/content/drive/MyDrive/iot_lightweight_transfer'   # this repository on Drive
WORK = '/content/drive/MyDrive/iot_experiment/work'        # data, PCAPs and results
FORCE = False                                              # True = recompute this step

from google.colab import drive
drive.mount('/content/drive')
import os, glob, subprocess, shutil, zipfile
SRC = f'{REPO}/src'
PC = f'{WORK}/pcaps'
os.makedirs(PC, exist_ok=True)
os.chdir(WORK)
subprocess.run('pip install -q -r ' + f'{REPO}/requirements.txt', shell=True)
subprocess.run('apt-get -qq install -y tcpdump', shell=True, capture_output=True)
print('repo:', REPO, '| work dir:', WORK)'''


def nb(cells):
    out = []
    for kind, src in cells:
        c = {"cell_type": kind, "metadata": {}, "source": src.strip("\n").splitlines(True)}
        if kind == "code":
            c.update(execution_count=None, outputs=[])
        out.append(c)
    return {"cells": out, "metadata": {"colab": {"provenance": []},
            "kernelspec": {"name": "python3", "display_name": "Python 3"}},
            "nbformat": 4, "nbformat_minor": 0}


def save(name, cells):
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        json.dump(nb(cells), f, indent=1, ensure_ascii=False)


# ------------------------------------------------------------------ 01
save("01_extract_cic_edge.ipynb", [
("markdown", """# 01 · Flow extraction for CIC-IoT-2023 and Edge-IIoTset
Produces `WORK/data/features_CICIoT2023.parquet` and `WORK/data/features_EdgeIIoT.parquet`.

**Inputs you must provide**
* CIC-IoT-2023 PCAPs (registration required at UNB CIC): put them in `WORK/pcaps/cic/` and set the
  file names in `CIC` below. The original run used `BenignTraffic.pcap`, `Recon-PortScan.pcap` and the
  DDoS SYN/UDP/ICMP/HTTP flood captures; the flood files were **partial browser downloads**, of which only
  the first 3M packets are used (see README, *Known deviations*).
* A Kaggle API token (`kaggle.json`) for Edge-IIoTset. Never commit it."""),
("code", SETUP),
("markdown", "## 1. Trim CIC-IoT-2023 captures to the first 3M packets"),
("code", r'''os.makedirs(f'{PC}/cic_clean', exist_ok=True)
CIC = {  # source file in WORK/pcaps/cic  ->  label
    'BenignTraffic.pcap': 'benign',
    'DDoS-SYN_Flood.pcap': 'ddos_syn',      # original run: partial download 'syn.crdownload'
    'DDoS-UDP_Flood.pcap': 'ddos_udp',      # exploratory class only
    'DDoS-ICMP_Flood.pcap': 'ddos_icmp',    # exploratory class only
    'DDoS-HTTP_Flood.pcap': 'ddos_http',    # exploratory class only
    'Recon-PortScan.pcap': 'portscan',
}
for src, lab in CIC.items():
    t = f'{PC}/cic_clean/{lab}_1.pcap'
    if os.path.exists(t) and not FORCE:
        print('exists:', lab); continue
    s = f'{PC}/cic/{src}'
    assert os.path.exists(s), f'missing {s}'
    subprocess.run(['tcpdump', '-r', s, '-c', '3000000', '-w', t], capture_output=True)
    print('done:', lab, f'{os.path.getsize(t)/1e6:.0f} MB')'''),
("markdown", "## 2. Download Edge-IIoTset PCAPs from Kaggle and trim"),
("code", r'''KG = 'mohamedamineferrag/edgeiiotset-cyber-security-dataset-of-iot-iiot'
A, N = 'Edge-IIoTset dataset/Attack traffic/', 'Edge-IIoTset dataset/Normal traffic/'
EDGE = [(A + 'DDoS TCP SYN Flood Attacks.pcap', 'ddos_syn_1'),
        (A + 'DDoS UDP Flood Attacks.pcap', 'ddos_udp_1'),
        (A + 'DDoS ICMP Flood Attacks.pcap', 'ddos_icmp_1'),
        (A + 'DDoS HTTP Flood Attacks.pcap', 'ddos_http_1'),
        (A + 'Port Scanning attack.pcap', 'portscan_1'),
        (N + 'Distance/Distance.pcap', 'benign_1'),
        (N + 'Flame_Sensor/Flame_Sensor.pcap', 'benign_2'),
        (N + 'Modbus/Modbus.pcap', 'benign_3'),
        (N + 'Heart_Rate/Heart_Rate.pcap', 'benign_4'),
        (N + 'phValue/phValue.pcap', 'benign_5')]
RAW, ECL = f'{PC}/edge_raw', f'{PC}/edge_clean'
os.makedirs(RAW, exist_ok=True); os.makedirs(ECL, exist_ok=True)
MAGIC = {b'\xd4\xc3\xb2\xa1', b'\xa1\xb2\xc3\xd4', b'\x4d\x3c\xb2\xa1', b'\xa1\xb2\x3c\x4d', b'\x0a\x0d\x0d\x0a'}
head = lambda p: open(p, 'rb').read(4)
files_in = lambda d: [p for p in glob.glob(f'{d}/**/*', recursive=True) if os.path.isfile(p)]
if not os.path.exists('/root/.kaggle/kaggle.json'):
    from google.colab import files
    print('Upload kaggle.json'); up = files.upload()
    os.makedirs('/root/.kaggle', exist_ok=True)
    open('/root/.kaggle/kaggle.json', 'wb').write(up['kaggle.json'])
    os.chmod('/root/.kaggle/kaggle.json', 0o600)
for kpath, name in EDGE:
    t = f'{ECL}/{name}.pcap'
    if os.path.exists(t) and not FORCE:
        print('exists:', name); continue
    d = f'{RAW}/{name}'; os.makedirs(d, exist_ok=True)
    if not files_in(d):
        subprocess.run(['kaggle', 'datasets', 'download', KG, '-f', kpath, '-p', d], capture_output=True)
    for p in files_in(d):                      # Kaggle may deliver a zip
        if head(p) == b'PK\x03\x04':
            zipfile.ZipFile(p).extractall(d); os.remove(p)
    pc = [p for p in files_in(d) if head(p) in MAGIC]
    assert pc, f'no PCAP found for {name}'
    subprocess.run(['tcpdump', '-r', pc[0], '-c', '3000000', '-w', t], capture_output=True)
    print('done:', name, f'{os.path.getsize(t)/1e6:.0f} MB')'''),
("markdown", "## 3. Cut high-rate floods to 400k packets (CIC SYN; Edge SYN/UDP/ICMP)"),
("code", r'''HEAVY = [f'{PC}/cic_clean/ddos_syn_1.pcap', f'{PC}/edge_clean/ddos_syn_1.pcap',
         f'{PC}/edge_clean/ddos_udp_1.pcap', f'{PC}/edge_clean/ddos_icmp_1.pcap']
for s in HEAVY:
    t = s.replace('_1.pcap', '_400k.pcap')
    if not os.path.exists(t) or FORCE:
        subprocess.run(['tcpdump', '-r', s, '-c', '400000', '-w', t], capture_output=True)
    print(t, f'{os.path.getsize(t)/1e6:.0f} MB')'''),
("markdown", "## 4. Manifest with attacker/victim addresses, then flow extraction"),
("code", r'''import pandas as pd
man = pd.read_csv(f'{REPO}/data/manifest_cic_edge.csv')
man['path'] = man['file'].map(lambda f: f'{PC}/{f}')
for p in man.path:
    assert os.path.exists(p), f'missing {p}'
man[['dataset', 'label', 'path', 'attacker_ips', 'victim_ips']].fillna('').to_csv('manifest.csv', index=False)
have = all(os.path.exists(f'data/features_{d}.parquet') for d in ['CICIoT2023', 'EdgeIIoT'])
if have and not FORCE:
    print('features exist, skipping')
else:
    subprocess.run(f'python {SRC}/build_dataset.py --manifest manifest.csv --out data', shell=True, check=True)
for d in ['CICIoT2023', 'EdgeIIoT']:
    print(d, pd.read_parquet(f'data/features_{d}.parquet', columns=['label']).label.value_counts().to_dict())'''),
("markdown", "## 5. Record hashes of the trimmed captures (for the data-provenance table)"),
("code", r'''subprocess.run(f'python {REPO}/tools/hash_pcaps.py {PC}/cic_clean {PC}/edge_clean --out {WORK}/pcap_hashes_cic_edge.csv', shell=True, check=True)
print(pd.read_csv(f'{WORK}/pcap_hashes_cic_edge.csv').to_string(index=False))'''),
])

# ------------------------------------------------------------------ 02
save("02_gotham_and_common_classes.ipynb", [
("markdown", """# 02 · Gotham 2025: download, labels, flows; build the three-dataset set `data3`
Reads only the needed members of the 24 GB Zenodo archive via HTTP range requests (~0.7 GB).
Requires notebook 01 to have produced the CIC-IoT-2023 and Edge-IIoTset features."""),
("code", SETUP),
("code", r'''URL = 'https://zenodo.org/records/14502760/files/GothamDataset2025.zip?download=1'
GRAW = f'{PC}/gotham_clean'
LAB_DEVICES = 'city-power-1,domotic-monitor-1,air-quality-1,combined-cycle-10'
for d in ['CICIoT2023', 'EdgeIIoT']:
    assert os.path.exists(f'data/features_{d}.parquet'), 'run notebook 01 first'
subprocess.run(f'python {SRC}/gotham_fetch.py --src "{URL}" --out "{GRAW}" --max-mb 60 --attack-devices "{LAB_DEVICES}"', shell=True, check=True)
subprocess.run(f'python {SRC}/gotham_labels.py --src "{URL}" --devices "{LAB_DEVICES}" --out "{PC}/gotham_labels.parquet"', shell=True, check=True)
if not os.path.exists('data/features_Gotham.parquet') or FORCE:
    subprocess.run(f'python {SRC}/gotham_build.py --raw "{GRAW}" --labels "{PC}/gotham_labels.parquet" --out data', shell=True, check=True)'''),
("code", r'''import pandas as pd
KEEP = ['benign', 'ddos_syn', 'portscan']          # classes shared by all three datasets
os.makedirs('data3', exist_ok=True)
for d in ['CICIoT2023', 'EdgeIIoT', 'Gotham']:
    x = pd.read_parquet(f'data/features_{d}.parquet')
    x = x[x.label.isin(KEEP)]
    x.to_parquet(f'data3/features_{d}.parquet', index=False)
    print(d, x.label.value_counts().to_dict())
# expected: CIC 50000/50000/50000; Edge 158142/50000/9987; Gotham 88255/10000/1146
subprocess.run(f'python {REPO}/tools/hash_pcaps.py {PC}/gotham_clean --out {WORK}/pcap_hashes_gotham.csv', shell=True, check=True)'''),
])

# ------------------------------------------------------------------ 03-06
def exp_nb(fname, title, intro, run, check):
    save(fname, [("markdown", f"# {title}\n{intro}"), ("code", SETUP), ("code", run), ("code", check)])

exp_nb("03_E2_timing_features.ipynb", "03 · E2: timing-feature sets FS1–FS6",
       "Four models × six feature sets, 3 seeds, all six transfer directions. ~1–2 h on a Colab CPU.",
       r'''if not os.path.exists('results3/results.csv') or FORCE:
    subprocess.run(f'python {SRC}/run_experiment.py --data data3 --out results3 --seeds 3', shell=True, check=True)
subprocess.run(f'python {SRC}/analyze.py --results results3 --data data3 --prevalence 0.1', shell=True, check=True)''',
       r'''import pandas as pd
print(pd.read_csv('results3/contrasts_f1_prev0.1.csv').round(3).to_string(index=False))
# compare with REPO/results/E2_timing/contrasts_f1_prev0.1.csv''')

exp_nb("04_E3_benign_diversity.ipynb", "04 · E3: benign-traffic diversity at fixed volume",
       "DT and MLP_S, 5,000 benign + 5,000 attack flows, k benign groups, up to 4 combinations per k, 3 seeds.",
       r'''if not os.path.exists('results_diversity3/diversity_results.csv') or FORCE:
    subprocess.run(f'python {SRC}/diversity3.py --data data3 --out results_diversity3 --seeds 3', shell=True, check=True)''',
       r'''import pandas as pd
d = pd.read_csv('results_diversity3/diversity_results.csv')
d = d[d.eval_on != 'source']
print(d.groupby(['experiment', 'k']).false_alarm.mean().round(3).unstack().to_string())''')

exp_nb("05_E3b_E4_controls.ipynb", "05 · E3b (diversity vs volume) and E4 (label-free adaptation)",
       "Needs `results_diversity3` from notebook 04 for the pooled H1 mixed model.",
       r'''if not os.path.exists('results_v5/volume_results.csv') or FORCE:
    subprocess.run(f'python {SRC}/v5_experiments.py volume --data data3 --out results_v5 --seeds 3', shell=True, check=True)
if not os.path.exists('results_v5/adapt_results.csv') or FORCE:
    subprocess.run(f'python {SRC}/v5_experiments.py adapt --data data3 --out results_v5 --seeds 3', shell=True, check=True)
subprocess.run(f'python {SRC}/v5_analyze.py --div results_diversity3/diversity_results.csv --v5 results_v5', shell=True, check=True)''',
       r'''import pandas as pd
print(pd.read_csv('results_v5/mixed_models.csv').round(4).to_string(index=False))''')

exp_nb("06_E1_lightweight_models.ipynb", "06 · E1: lightweight neural networks, float32 vs full INT8 (TensorFlow Lite)",
       "Keras models converted to TFLite and evaluated with the TFLite interpreter. ~30 min on a Colab CPU.",
       r'''if not os.path.exists('results_v6/v6_results.csv') or FORCE:
    subprocess.run(f'python {SRC}/v6_lightweight.py --data data3 --out results_v6 --seeds 3', shell=True, check=True)
subprocess.run(f'python {SRC}/v6_analyze.py --dir results_v6', shell=True, check=True)''',
       r'''import pandas as pd
for t in ['T1_in_vs_cross', 'T2_quantization_cost', 'T3_resources']:
    print(t); print(pd.read_csv(f'results_v6/{t}.csv').to_string(index=False))''')
print(sorted(os.listdir(OUT)))

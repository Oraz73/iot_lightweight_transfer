"""Кросс-датасетный эксперимент: какие временные признаки помогают переносу.

Для каждого сида, модели, набора признаков и упорядоченной пары
(источник -> цель) модель обучается на источнике и БЕЗ дообучения
тестируется на цели. Диагональ (источник = цель) - оценка внутри домена.

Метрики считаются при двух распространённостях атак в тесте:
  native - как в датасете (часто нереалистично много атак);
  0.10   - взвешенная оценка при 10% атак (ближе к реальной сети).
"""
import argparse
import glob
import os
import time
import warnings

import numpy as np
import pandas as pd
from sklearn.metrics import (average_precision_score, f1_score,
                             matthews_corrcoef, precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from features import FEATURE_SETS, columns_for, resource_estimate

warnings.filterwarnings("ignore")


def load(data_dir):
    d = {}
    for fn in sorted(glob.glob(os.path.join(data_dir, "features_*.parquet"))):
        df = pd.read_parquet(fn)
        d[df["dataset"].iloc[0]] = df
    return d


def split(df, seed, test_size):
    tr, te = train_test_split(df.index, test_size=test_size, random_state=seed,
                              stratify=df["label"])
    return df.loc[tr], df.loc[te]


def balanced_sample(df, n_per_class, seed):
    rng = np.random.default_rng(seed)
    parts = []
    for y in (0, 1):
        idx = df.index[df["is_attack"] == y]
        if len(idx) == 0:
            continue
        parts.append(rng.choice(idx, min(n_per_class, len(idx)), replace=False))
    return df.loc[np.concatenate(parts)]


def weights_for(y, prevalence):
    """Веса, при которых доля атак в тесте равна prevalence."""
    p = y.mean()
    if prevalence == "native" or p in (0, 1):
        return np.ones(len(y))
    pi = float(prevalence)
    return np.where(y == 1, pi / p, (1 - pi) / (1 - p))


def metrics(y, yhat, score, w):
    out = {
        "f1": f1_score(y, yhat, sample_weight=w, zero_division=0),
        "precision": precision_score(y, yhat, sample_weight=w, zero_division=0),
        "recall": recall_score(y, yhat, sample_weight=w, zero_division=0),
        "mcc": matthews_corrcoef(y, yhat, sample_weight=w),
    }
    try:
        out["pr_auc"] = average_precision_score(y, score, sample_weight=w)
    except ValueError:
        out["pr_auc"] = np.nan
    return out


def n_params_mlp(m):
    return int(sum(c.size for c in m.coefs_) + sum(b.size for b in m.intercepts_))


def make_models(seed):
    return {
        "DT": lambda: DecisionTreeClassifier(max_depth=10, random_state=seed),
        "MLP_S": lambda: MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=200, early_stopping=True,
                                       random_state=seed),
        "MLP_M": lambda: MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=200, early_stopping=True,
                                       random_state=seed),
        "AE": lambda: MLPRegressor(hidden_layer_sizes=(16, 4, 16), max_iter=200, early_stopping=True,
                                   random_state=seed),
    }


def fit_predict(name, factory, Xtr, ytr, seed):
    """Возвращает функцию predict(X) -> (yhat, score) и размер модели."""
    if name == "AE":
        Xb = Xtr[ytr == 0]
        Xfit, Xval = train_test_split(Xb, test_size=0.2, random_state=seed)
        m = factory().fit(Xfit, Xfit)
        err = lambda X: ((m.predict(X) - X) ** 2).mean(axis=1)
        thr = np.quantile(err(Xval), 0.99)
        return (lambda X: (err(X) > thr).astype(int)), err, n_params_mlp(m)
    m = factory().fit(Xtr, ytr)
    size = int(m.tree_.node_count) if name == "DT" else n_params_mlp(m)
    return m.predict, (lambda X: m.predict_proba(X)[:, 1]), size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="results")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--n-per-class", type=int, default=30000)
    ap.add_argument("--test-size", type=float, default=0.3)
    ap.add_argument("--models", default="DT,MLP_S,MLP_M,AE")
    ap.add_argument("--prevalences", default="native,0.1")
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    data = load(a.data)
    names = list(data)
    if len(names) < 2:
        raise SystemExit("нужно минимум 2 датасета в папке data/")
    print("датасеты:", {k: len(v) for k, v in data.items()})
    feat_cols = [c for c in next(iter(data.values())).columns if "__" in c]
    prevs = a.prevalences.split(",")
    models_sel = a.models.split(",")

    # каждый блок (сид, набор признаков) сохраняется сразу; при перезапуске
    # готовые блоки пропускаются
    ck_res = os.path.join(a.out, "results_partial.csv")
    ck_lab = os.path.join(a.out, "per_label_partial.csv")
    done = set()
    if os.path.exists(ck_res):
        d0 = pd.read_csv(ck_res, usecols=["seed", "feature_set"])
        done = set(map(tuple, d0.values))
    t0 = time.time()
    for seed in range(a.seeds):
        splits = None
        for fs in FEATURE_SETS:
            if (seed, fs) in done:
                print(f"seed {seed} {fs}: уже есть, пропуск", flush=True)
                continue
            if splits is None:
                splits = {k: split(v, seed, a.test_size) for k, v in data.items()}
            rows, rows_lab = [], []
            cols = columns_for(fs, feat_cols)
            for src in names:
                tr = balanced_sample(splits[src][0], a.n_per_class, seed)
                sc = StandardScaler().fit(tr[cols].values)
                Xtr = sc.transform(tr[cols].values)
                ytr = tr["is_attack"].values
                for mname, fac in make_models(seed).items():
                    if mname not in models_sel:
                        continue
                    pred, score, size = fit_predict(mname, fac, Xtr, ytr, seed)
                    for tgt in names:
                        te = splits[tgt][1]
                        Xte = sc.transform(te[cols].values)
                        y = te["is_attack"].values
                        yhat, s = pred(Xte), score(Xte)
                        labs = te["label"].values
                        for lab in np.unique(labs):
                            mk = labs == lab
                            rows_lab.append(dict(seed=seed, model=mname,
                                                 feature_set=fs, source=src,
                                                 target=tgt, label=lab,
                                                 flagged=float(yhat[mk].mean()),
                                                 n=int(mk.sum())))
                        for pv in prevs:
                            m = metrics(y, yhat, s, weights_for(y, pv))
                            rows.append(dict(seed=seed, model=mname, feature_set=fs,
                                             source=src, target=tgt,
                                             in_domain=src == tgt, prevalence=pv,
                                             n_features=len(cols), model_size=size,
                                             n_test=len(y), **m))
            pd.DataFrame(rows).to_csv(ck_res, mode="a", index=False,
                                      header=not os.path.exists(ck_res))
            pd.DataFrame(rows_lab).to_csv(ck_lab, mode="a", index=False,
                                          header=not os.path.exists(ck_lab))
            print(f"seed {seed} {fs} готово ({time.time()-t0:.0f} c)", flush=True)

    res = pd.read_csv(ck_res, dtype={"prevalence": str})
    res.to_csv(os.path.join(a.out, "results.csv"), index=False)
    pd.read_csv(ck_lab).to_csv(os.path.join(a.out, "per_label.csv"), index=False)
    pd.DataFrame([resource_estimate(fs) for fs in FEATURE_SETS]).to_csv(
        os.path.join(a.out, "resource_estimate.csv"), index=False)
    print("сохранено:", os.path.join(a.out, "results.csv"), len(res), "строк")


if __name__ == "__main__":
    main()

"""v6: сравнение лёгких нейросетей (float32 и INT8) при переносе между сетями.

Модели (Keras): MLP_S (16-8), MLP_M (64-32), CNN1D (свёртки 8 и 16 по вектору
признаков + глобальное усреднение), AE (16-4-16, обучение только на
нормальном трафике, порог - 99-й перцентиль ошибки на валидации).
Базовая модель: дерево решений (глубина 10).

Каждая нейросеть конвертируется в TensorFlow Lite дважды:
  fp32 - без квантования;
  int8 - полное целочисленное квантование после обучения (веса и
         активации INT8, калибровка на 500 обучающих примерах), формат,
         который исполняет TensorFlow Lite Micro на микроконтроллерах.
Оценка - через интерпретатор TFLite (то есть ровно та модель, что пошла бы
на устройство), на тесте своего датасета и на двух чужих.

Ресурсы: число параметров, размер файла .tflite, задержка одного вызова
(batch = 1) на CPU среды исполнения - это НЕ замер на микроконтроллере.

Каждый блок (сид, источник) сохраняется сразу; при перезапуске готовое
пропускается.
"""
import argparse
import glob
import os
import pickle
import time
import warnings

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from features import columns_for

tf.get_logger().setLevel("ERROR")


def f1_at(y, yhat, prev=0.1):
    p = y.mean()
    if p in (0, 1):
        return np.nan
    w = np.where(y == 1, prev / p, (1 - prev) / (1 - p))
    return f1_score(y, yhat, sample_weight=w, zero_division=0)


def build(name, d):
    L = tf.keras.layers
    if name == "MLP_S":
        return tf.keras.Sequential([L.Input((d,)), L.Dense(16, activation="relu"),
                                    L.Dense(8, activation="relu"),
                                    L.Dense(1, activation="sigmoid")])
    if name == "MLP_M":
        return tf.keras.Sequential([L.Input((d,)), L.Dense(64, activation="relu"),
                                    L.Dense(32, activation="relu"),
                                    L.Dense(1, activation="sigmoid")])
    if name == "CNN1D":
        return tf.keras.Sequential([L.Input((d,)), L.Reshape((d, 1)),
                                    L.Conv1D(8, 3, padding="same", activation="relu"),
                                    L.Conv1D(16, 3, padding="same", activation="relu"),
                                    L.GlobalAveragePooling1D(),
                                    L.Dense(1, activation="sigmoid")])
    if name == "AE":
        return tf.keras.Sequential([L.Input((d,)), L.Dense(16, activation="relu"),
                                    L.Dense(4, activation="relu"),
                                    L.Dense(16, activation="relu"), L.Dense(d)])
    raise ValueError(name)


def train(name, X, y, seed, epochs):
    tf.keras.utils.set_random_seed(seed)
    m = build(name, X.shape[1])
    m.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
              loss="mse" if name == "AE" else "binary_crossentropy")
    cb = [tf.keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True)]
    if name == "AE":
        Xb = X[y == 0]
        m.fit(Xb, Xb, epochs=epochs, batch_size=256, validation_split=0.1,
              callbacks=cb, verbose=0)
    else:
        m.fit(X, y.astype("float32"), epochs=epochs, batch_size=256,
              validation_split=0.1, callbacks=cb, verbose=0)
    return m


def to_tflite(model, Xcal, int8):
    conv = tf.lite.TFLiteConverter.from_keras_model(model)
    if int8:
        conv.optimizations = [tf.lite.Optimize.DEFAULT]
        rep = Xcal.astype("float32")
        conv.representative_dataset = lambda: ([rep[i:i + 1]] for i in range(len(rep)))
        conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
        conv.inference_input_type = tf.int8
        conv.inference_output_type = tf.int8
    return conv.convert()


class TFLiteModel:
    def __init__(self, blob, batch=2048):
        self.blob, self.batch = blob, batch
        self.it = tf.lite.Interpreter(model_content=blob)
        self.inp = self.it.get_input_details()[0]
        self.out = self.it.get_output_details()[0]
        self.cur = None

    def _resize(self, n):
        if self.cur != n:
            self.it.resize_tensor_input(self.inp["index"], [n, self.inp["shape"][1]])
            self.it.allocate_tensors()
            self.inp = self.it.get_input_details()[0]
            self.out = self.it.get_output_details()[0]
            self.cur = n

    def _q(self, x):
        if self.inp["dtype"] == np.int8:
            s, z = self.inp["quantization"]
            return np.clip(np.round(x / s + z), -128, 127).astype(np.int8)
        return x.astype(np.float32)

    def _dq(self, y):
        if self.out["dtype"] == np.int8:
            s, z = self.out["quantization"]
            return (y.astype(np.float32) - z) * s
        return y

    def predict(self, X):
        outs = []
        for i in range(0, len(X), self.batch):
            xb = X[i:i + self.batch]
            self._resize(len(xb))
            self.it.set_tensor(self.inp["index"], self._q(xb))
            self.it.invoke()
            outs.append(self._dq(self.it.get_tensor(self.out["index"])))
        return np.concatenate(outs)

    def latency_us(self, x1, reps=500):
        self._resize(1)
        q = self._q(x1[:1])
        for _ in range(20):
            self.it.set_tensor(self.inp["index"], q)
            self.it.invoke()
        t = []
        for _ in range(reps):
            t0 = time.perf_counter()
            self.it.set_tensor(self.inp["index"], q)
            self.it.invoke()
            t.append(time.perf_counter() - t0)
        return float(np.median(t) * 1e6)


def decide(name, raw, X, thr=None):
    if name == "AE":
        return (((raw - X) ** 2).mean(axis=1) > thr).astype(int)
    return (raw.ravel() > 0.5).astype(int)


def metrics(y, yhat):
    return dict(f1_prev10=f1_at(y, yhat),
                false_alarm=float(yhat[y == 0].mean()),
                detection=float(yhat[y == 1].mean()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data3")
    ap.add_argument("--out", default="results_v6")
    ap.add_argument("--keep", default="benign,ddos_syn,portscan")
    ap.add_argument("--feature-set", default="FS1_base")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--n-per-class", type=int, default=10000)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--models", default="MLP_S,MLP_M,CNN1D,AE")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    data = {}
    for fn in sorted(glob.glob(os.path.join(a.data, "features_*.parquet"))):
        d = pd.read_parquet(fn)
        d = d[d["label"].isin(a.keep.split(","))].reset_index(drop=True)
        data[d["dataset"].iloc[0]] = d
    names = list(data)
    cols = columns_for(a.feature_set, [c for c in data[names[0]].columns if "__" in c])
    print("датасеты:", {k: len(v) for k, v in data.items()}, "| признаков:", len(cols))

    ck = os.path.join(a.out, "v6_partial.csv")
    ckr = os.path.join(a.out, "v6_resources_partial.csv")
    done = set()
    if os.path.exists(ck):
        d0 = pd.read_csv(ck, usecols=["seed", "source"])
        done = set(map(tuple, d0.astype(str).values))

    for seed in range(a.seeds):
        splits = {k: train_test_split(v, test_size=0.3, random_state=seed,
                                      stratify=v["label"]) for k, v in data.items()}
        for src in names:
            if (str(seed), src) in done:
                print(f"seed {seed} {src}: уже есть, пропуск", flush=True)
                continue
            t0 = time.time()
            tr_all = splits[src][0]
            rng = np.random.default_rng(seed)
            idx = np.concatenate([
                rng.choice(tr_all.index[tr_all.is_attack == c].values,
                           min(a.n_per_class, int((tr_all.is_attack == c).sum())),
                           replace=False) for c in (0, 1)])
            tr = tr_all.loc[idx]
            sc = StandardScaler().fit(tr[cols].values)
            X = sc.transform(tr[cols].values).astype("float32")
            y = tr["is_attack"].values
            Xtr, Xval, ytr, yval = train_test_split(X, y, test_size=0.15,
                                                    random_state=seed, stratify=y)
            tests = {t: (sc.transform(splits[t][1][cols].values).astype("float32"),
                         splits[t][1]["is_attack"].values) for t in names}
            rows, res_rows = [], []

            dt = DecisionTreeClassifier(max_depth=10, random_state=seed).fit(Xtr, ytr)
            for t, (Xt, yt) in tests.items():
                rows.append(dict(seed=seed, source=src, target=t, in_domain=t == src,
                                 model="DT", precision="fp32",
                                 **metrics(yt, dt.predict(Xt))))
            lat = []
            for _ in range(200):
                t1 = time.perf_counter()
                dt.predict(Xval[:1])
                lat.append(time.perf_counter() - t1)
            res_rows.append(dict(seed=seed, source=src, model="DT", precision="fp32",
                                 n_params=int(dt.tree_.node_count),
                                 size_bytes=len(pickle.dumps(dt)),
                                 latency_us=float(np.median(lat) * 1e6)))

            for name in a.models.split(","):
                km = train(name, Xtr, ytr, seed, a.epochs)
                for prec in ["fp32", "int8"]:
                    blob = to_tflite(km, Xtr[:500], prec == "int8")
                    tm = TFLiteModel(blob)
                    thr = None
                    if name == "AE":
                        Xvb = Xval[yval == 0]
                        err = ((tm.predict(Xvb) - Xvb) ** 2).mean(axis=1)
                        thr = float(np.quantile(err, 0.99))
                    for t, (Xt, yt) in tests.items():
                        yhat = decide(name, tm.predict(Xt), Xt, thr)
                        rows.append(dict(seed=seed, source=src, target=t,
                                         in_domain=t == src, model=name,
                                         precision=prec, **metrics(yt, yhat)))
                    res_rows.append(dict(seed=seed, source=src, model=name,
                                         precision=prec,
                                         n_params=int(km.count_params()),
                                         size_bytes=len(blob),
                                         latency_us=tm.latency_us(Xval)))
                tf.keras.backend.clear_session()
            for path, rr in [(ck, rows), (ckr, res_rows)]:
                pd.DataFrame(rr).to_csv(path, mode="a", index=False,
                                        header=not os.path.exists(path))
            print(f"seed {seed} {src}: готово ({time.time()-t0:.0f} c)", flush=True)

    pd.read_csv(ck).to_csv(os.path.join(a.out, "v6_results.csv"), index=False)
    pd.read_csv(ckr).to_csv(os.path.join(a.out, "v6_resources.csv"), index=False)
    print("сохранено в", a.out)


if __name__ == "__main__":
    main()

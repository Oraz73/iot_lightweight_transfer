"""Анализ v5: смешанные модели и графики.

Смешанные линейные модели (statsmodels MixedLM), случайный свободный член
для каждого направления переноса (источник -> цель), модель детектора -
фиксированный эффект:
  H1  (v4):  false_alarm ~ log2(k) + C(model)
  А:         false_alarm ~ log2(k) + log2(V) + C(model)
  Б:         false_alarm ~ log2(k_t + 1) + C(model)
Если модель со случайным наклоном сходится, сообщается и она.
"""
import argparse
import os
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

warnings.filterwarnings("ignore")
SURF, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#6250d6"]


def style(ax):
    ax.set_facecolor(SURF)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    for s in ["left", "bottom"]:
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.yaxis.grid(True, color=GRID, lw=0.8)
    ax.set_axisbelow(True)


def mixed(df, formula, group, label, terms, slope=None):
    rows = []
    for spec, re_f in [("intercept", None), ("intercept+slope", slope)]:
        if spec == "intercept+slope" and slope is None:
            continue
        try:
            m = smf.mixedlm(formula, df, groups=df[group],
                            re_formula=re_f).fit(reml=True, method="lbfgs")
            ci = m.conf_int()
            for t in terms:
                rows.append(dict(analysis=label, random=spec, term=t,
                                 coef=m.params[t], ci_low=ci.loc[t, 0],
                                 ci_high=ci.loc[t, 1], p=m.pvalues[t],
                                 n_obs=int(m.nobs), n_groups=df[group].nunique(),
                                 converged=bool(m.converged)))
        except Exception as e:  # noqa: BLE001
            rows.append(dict(analysis=label, random=spec, term="ОШИБКА",
                             coef=np.nan, ci_low=np.nan, ci_high=np.nan, p=np.nan,
                             n_obs=len(df), n_groups=df[group].nunique(),
                             converged=False, error=str(e)[:120]))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--div", default="results_diversity3/diversity_results.csv")
    ap.add_argument("--v5", default="results_v5")
    a = ap.parse_args()
    out = []

    # --- H1 (v4): смешанная модель вместо Спирмена по точкам k
    if os.path.exists(a.div):
        d = pd.read_csv(a.div)
        d = d[d.eval_on != "source"].copy()
        d["log2k"] = np.log2(d["k"])
        d["pair"] = d["experiment"] + "->" + d["eval_on"]
        out += mixed(d, "false_alarm ~ log2k + C(model)", "pair", "H1 все источники",
                     ["log2k"], slope="~log2k")
        for exp, g in d.groupby("experiment"):
            out += mixed(g, "false_alarm ~ log2k + C(model)", "pair", f"H1 {exp}",
                         ["log2k"])

    # --- А: объём против разнообразия
    fv = os.path.join(a.v5, "volume_results.csv")
    if os.path.exists(fv):
        v = pd.read_csv(fv)
        v["log2k"], v["log2V"] = np.log2(v["k"]), np.log2(v["V"])
        v["pair"] = v["source"] + "->" + v["target"]
        out += mixed(v, "false_alarm ~ log2k + log2V + C(model)", "pair",
                     "А объём vs разнообразие", ["log2k", "log2V"])
        out += mixed(v, "f1_prev10 ~ log2k + log2V + C(model)", "pair",
                     "А (F1) объём vs разнообразие", ["log2k", "log2V"])
        srcs = list(dict.fromkeys(v.source))
        fig, axes = plt.subplots(1, len(srcs), figsize=(4.3 * len(srcs), 3.6),
                                 facecolor=SURF, sharey=True)
        for ax, s in zip(np.atleast_1d(axes), srcs):
            style(ax)
            g = v[v.source == s]
            for i, (k, gk) in enumerate(sorted(g.groupby("k"))):
                m = gk.groupby("V")["false_alarm"].mean()
                ax.plot(m.index, m.values, "-o", color=SERIES[i % 4], lw=2, ms=5,
                        mec=SURF, mew=1.2, label=f"k = {k}")
            ax.set_xscale("log", base=2)
            vs = sorted(g.V.unique())
            ax.set_xticks(vs)
            ax.set_xticklabels([str(x) for x in vs])
            ax.minorticks_off()
            ax.set_title(f"обучение: {s}", color=INK, loc="left", fontsize=9)
            ax.set_xlabel("V - нормальных потоков при обучении", color=INK2, fontsize=8)
            ax.legend(frameon=False, fontsize=7, title="групп", title_fontsize=7)
        np.atleast_1d(axes)[0].set_ylabel("ложные тревоги на чужих сетях", color=INK2,
                                          fontsize=8)
        fig.suptitle("А: объём (ось X) против разнообразия (линии); среднее по целям и моделям",
                     color=INK, fontsize=10, x=0.01, ha="left")
        fig.tight_layout()
        fig.savefig(os.path.join(a.v5, "fig_A_volume_vs_diversity.png"), dpi=200)
        plt.close(fig)
        (v.groupby(["source", "k", "V"])[["false_alarm", "detection", "f1_prev10"]]
          .mean().round(3).to_csv(os.path.join(a.v5, "A_means.csv")))

    # --- Б: протокол для новой сети
    fa = os.path.join(a.v5, "adapt_results.csv")
    if os.path.exists(fa):
        b = pd.read_csv(fa)
        b["log2k1"] = np.log2(b["k_t"] + 1)
        b["pair"] = b["source"] + "->" + b["target"]
        out += mixed(b, "false_alarm ~ log2k1 + C(model)", "pair",
                     "Б адаптация: ложные тревоги", ["log2k1"])
        out += mixed(b, "detection ~ log2k1 + C(model)", "pair",
                     "Б адаптация: обнаружение", ["log2k1"])
        pairs = list(dict.fromkeys(b.pair))
        ncol = 3
        nrow = int(np.ceil(len(pairs) / ncol))
        fig, axes = plt.subplots(nrow, ncol, figsize=(4.3 * ncol, 3.3 * nrow),
                                 facecolor=SURF, sharey=True)
        for ax, p in zip(np.ravel(axes), pairs):
            style(ax)
            g = b[b.pair == p]
            for i, (mdl, gm) in enumerate(sorted(g.groupby("model"))):
                for metric, ls in [("false_alarm", "-"), ("detection", ":")]:
                    m = gm.groupby("k_t")[metric].mean()
                    ax.plot(m.index, m.values, ls + "o", color=SERIES[i], lw=2, ms=4,
                            mec=SURF, mew=1,
                            label=f"{mdl}: {'ложн. тревоги' if metric == 'false_alarm' else 'обнаружение'}")
            ks = sorted(g.k_t.unique())
            ax.set_xticks(ks)
            ax.set_ylim(-0.02, 1.02)
            ax.set_title(p.replace("->", " → "), color=INK, loc="left", fontsize=9)
            ax.set_xlabel("k_t - устройств новой сети в дообучении", color=INK2, fontsize=8)
        for ax in np.ravel(axes)[len(pairs):]:
            ax.axis("off")
        np.ravel(axes)[0].legend(frameon=False, fontsize=6)
        fig.suptitle("Б: дообучение только на нормальном трафике новой сети "
                     "(оценка на других её устройствах)", color=INK, fontsize=10,
                     x=0.01, ha="left")
        fig.tight_layout()
        fig.savefig(os.path.join(a.v5, "fig_B_adaptation.png"), dpi=200)
        plt.close(fig)
        (b.groupby(["source", "target", "model", "k_t"])
          [["false_alarm", "detection", "f1_prev10"]].mean().round(3)
          .to_csv(os.path.join(a.v5, "B_means.csv")))

    res = pd.DataFrame(out)
    res.to_csv(os.path.join(a.v5, "mixed_models.csv"), index=False)
    print(res.round(4).to_string(index=False))


if __name__ == "__main__":
    main()

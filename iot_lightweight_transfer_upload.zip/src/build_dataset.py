"""PCAP -> единая таблица признаков для каждого датасета.

Колонки manifest.csv: dataset,label,path,attacker_ips,victim_ips
  label        - 'benign' для нормального трафика, иначе название атаки
  attacker_ips - (необяз.) оставить только потоки, где участвует один из IP
  victim_ips   - (необяз., для флуда с подменой IP) оставить потоки с жертвой,
                 у которых второй участник НЕ встречается в нормальном
                 трафике этого же датасета

Длинные потоки режутся окнами active_timeout (по умолчанию 10 с), чтобы
высокоскоростные флуды не схлопывались в единичные потоки.

Выход: <out>/features_<dataset>.parquet и <out>/filter_log.csv
"""
import argparse
import os

import numpy as np
import pandas as pd
from nfstream import NFStreamer

from features import compute_feature_groups


def ipset(x):
    x = str(x or "")
    if x == "nan":
        return set()
    return {i.strip() for i in x.split(";") if i.strip()}


def extract(path, idle, active):
    return NFStreamer(source=path, statistical_analysis=True,
                      idle_timeout=idle, active_timeout=active,
                      n_dissections=0, splt_analysis=0).to_pandas()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", default="data")
    ap.add_argument("--max-flows-per-file", type=int, default=50000)
    ap.add_argument("--idle-timeout", type=int, default=30)
    ap.add_argument("--active-timeout", type=int, default=10)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    man = pd.read_csv(a.manifest, dtype=str).fillna("")
    for c in ["attacker_ips", "victim_ips"]:
        if c not in man:
            man[c] = ""
    base = os.path.dirname(os.path.abspath(a.manifest))
    # нормальный трафик первым: из него собираем известные хосты датасета
    man["_o"] = (man["label"] != "benign").astype(int)
    man = man.sort_values(["dataset", "_o"], kind="stable")

    os.makedirs(a.out, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    parts, hosts, log = {}, {}, []
    for _, r in man.iterrows():
        ds = r["dataset"]
        path = r["path"] if os.path.isabs(r["path"]) else os.path.join(base, r["path"])
        print(f"[{ds}] {r['label']:<12} {os.path.basename(path)}", flush=True)
        f = extract(path, a.idle_timeout, a.active_timeout)
        n0 = len(f)
        if f.empty:
            print("   пусто, пропуск")
            continue
        if r["label"] == "benign":
            hosts.setdefault(ds, set()).update(set(f["src_ip"]) | set(f["dst_ip"]))
        else:
            att, vic = ipset(r["attacker_ips"]), ipset(r["victim_ips"])
            if att or vic:
                keep = pd.Series(False, index=f.index)
                if att:
                    keep |= f["src_ip"].isin(att) | f["dst_ip"].isin(att)
                if vic:
                    known = hosts.get(ds, set()) - vic
                    src_v = f["src_ip"].isin(vic)
                    touch = src_v | f["dst_ip"].isin(vic)
                    peer = pd.Series(np.where(src_v, f["dst_ip"], f["src_ip"]),
                                     index=f.index)
                    keep |= touch & ~peer.isin(known)
                f = f[keep]
        print(f"   потоков: {n0} -> после фильтра {len(f)}", flush=True)
        log.append([ds, r["label"], os.path.basename(path), n0, len(f)])
        if f.empty:
            continue
        if len(f) > a.max_flows_per_file:
            f = f.iloc[rng.choice(len(f), a.max_flows_per_file, replace=False)]
        f = f.reset_index(drop=True)
        g = compute_feature_groups(f)
        g["dataset"] = ds
        g["label"] = r["label"]
        g["is_attack"] = int(r["label"] != "benign")
        g["src_file"] = os.path.basename(path)
        g["src_ip"] = f["src_ip"].values
        g["dst_ip"] = f["dst_ip"].values
        parts.setdefault(ds, []).append(g)

    for ds, lst in parts.items():
        df = pd.concat(lst, ignore_index=True)
        fn = os.path.join(a.out, f"features_{ds}.parquet")
        df.to_parquet(fn, index=False)
        print(f"{ds}: {len(df)} потоков, атак {df.is_attack.mean():.1%} -> {fn}")
        print(df.groupby("label").size().to_string())
    pd.DataFrame(log, columns=["dataset", "label", "file", "flows_raw",
                               "flows_kept"]).to_csv(
        os.path.join(a.out, "filter_log.csv"), index=False)


if __name__ == "__main__":
    main()

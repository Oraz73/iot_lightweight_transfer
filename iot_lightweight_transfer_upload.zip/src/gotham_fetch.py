"""Выборочное извлечение PCAP из архива Gotham 2025 (без скачивания 24 ГБ).

Источник - URL архива на Zenodo (читается частями через HTTP Range, пакет
remotezip) или локальный путь к zip. Для больших файлов берётся только
начало (--max-mb); обрезанный последний пакет убирает tcpdump.

Результат: <out>/<scenario>/<device>.pcap, где scenario = benign | merlin |
network-scanning, device - имя устройства (например city-power-1).
"""
import argparse
import os
import shutil
import subprocess
import zipfile

SCENARIOS = {
    "raw/benign/": "benign",
    "raw/malicious/merlin/": "merlin",
    "raw/malicious/network-scanning/": "network-scanning",
}


def device_name(member):
    base = os.path.basename(member)
    return base.split("_")[0].replace("iotsim-", "")


def open_zip(src):
    if os.path.exists(src):
        return zipfile.ZipFile(src)
    from remotezip import RemoteZip
    return RemoteZip(src)


def copy_prefix(zf, member, dst, max_bytes):
    with zf.open(member) as fi, open(dst, "wb") as fo:
        left = max_bytes
        while left > 0:
            buf = fi.read(min(8 << 20, left))
            if not buf:
                break
            fo.write(buf)
            left -= len(buf)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="URL или путь к zip")
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-mb", type=int, default=60)
    ap.add_argument("--max-packets", type=int, default=400000)
    ap.add_argument("--attack-devices", default="",
                    help="через запятую; атаки брать только для этих устройств")
    a = ap.parse_args()
    tmp = os.path.join(a.out, "_tmp")
    os.makedirs(tmp, exist_ok=True)
    with open_zip(a.src) as zf:
        members = [i for i in zf.infolist() if i.filename.endswith(".pcap")]
        for info in members:
            scen = next((v for k, v in SCENARIOS.items()
                         if info.filename.startswith(k)), None)
            if scen is None:
                continue
            dev = device_name(info.filename)
            want = [x for x in a.attack_devices.split(",") if x]
            if scen != "benign" and want and dev not in want:
                continue
            os.makedirs(os.path.join(a.out, scen), exist_ok=True)
            dst = os.path.join(a.out, scen, f"{dev}.pcap")
            if os.path.exists(dst) and os.path.getsize(dst) > 0:
                continue
            raw = os.path.join(tmp, f"{scen}_{dev}.pcap")
            copy_prefix(zf, info.filename, raw, a.max_mb << 20)
            subprocess.run(["tcpdump", "-r", raw, "-c", str(a.max_packets),
                            "-w", dst], capture_output=True)
            os.remove(raw)
            if not os.path.exists(dst):
                print(f"ОШИБКА: {scen}/{dev}")
                continue
            part = " (начало)" if info.file_size > a.max_mb << 20 else ""
            print(f"{scen:17} {dev:28} {os.path.getsize(dst)/1e6:7.1f} МБ{part}",
                  flush=True)
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()

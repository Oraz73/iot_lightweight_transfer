"""Эксперимент на разнообразие нормального трафика для любого числа датасетов.

Для каждого источника (датасет + способ группировки нормального трафика)
модель обучается на нормальном трафике k групп при ФИКСИРОВАННОМ объёме
нормальных примеров и одних и тех же атаках, затем оценивается на тесте
своего датасета и на всех остальных датасетах.

Способы группировки (--sources "Датасет:способ[:префикс]", через запятую):
  file - файл PCAP (тип сенсора Edge; отдельное устройство Gotham);
  type - тип устройства: имя файла без номера (cooler-motor-3 -> cooler-motor);
  host - локальное устройство по IP с заданным префиксом (CIC: 192.168.137.).

Каждый блок (источник, сид, k) сохраняется сразу; при перезапуске готовые
блоки пропускаются.
"""
import argparse
import glob
import os
import warnings
from itertools import combinations
from math import comb

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from features import columns_for

warnings.filterwarnings("ignore")


def models(seed):
    return {
        "DT": lambda: DecisionTreeClassifier(max_depth=10, random_state=seed),
        "MLP_S": lambda: MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=200,
                                       early_stopping=True, random_state=seed),
    }


def f1_at(y, yhat, prev=0.1):
    p = y.mean()
    if p in (0, 1):
        return np.nan
    w = np.where(y == 1, prev / p, (1 - prev) / (1 - p))
    return f1_score(y, yhat, sample_weight=w, zero_division=0)


def pick_combos(groups, k, max_combos, rng, enum_limit=200000):
    if comb(len(groups), k) <= enum_limit:
        allc = list(combinations(groups, k))
        if len(allc) <= max_combos:
            return allc
        pick = rng.choice(len(allc), max_combos, replace=False)
        return [allc[i] for i in pick]
    seen = set()
    while len(seen) < max_combos:
        seen.add(tuple(sorted(rng.choice(groups, k, replace=False))))
    return sorted(seen)


def sample_groups(ben, groups, n_total, rng):
    per = max(1, n_total // len(groups))
    idx, replaced = [], False
    for g in groups:
        pool = ben.index[ben["group"] == g].values
        rep = len(pool) < per
        replaced |= rep
        idx.append(rng.choice(pool, per, replace=rep))
    return ben.loc[np.concatenate(idx)], replaced


def assign_groups(df, mode, prefix, min_flows):
    ben = df["label"] == "benign"
    if mode == "file":
        g = df["src_file"].astype(str)
    elif mode == "type":
        g = df["src_file"].astype(str).str.replace(r"[-_]?\d+$", "", regex=True)
    elif mode == "host":
        s, d = df["src_ip"].astype(str), df["dst_ip"].astype(str)
        g = pd.Series(np.where(s.str.startswith(prefix), s,
                               np.where(d.str.startswith(prefix), d, "other")),
                      index=df.index)
    else:
        raise ValueError(mode)
    df = df.copy()
    df["group"] = np.where(ben, g, "attack")
    cnt = df.loc[ben, "group"].value_counts()
    good = cnt[(cnt >= min_flows) & (cnt.index != "other")].index
    df = df[(~ben) | df["group"].isin(good)].reset_index(drop=True)
    return df, sorted(good)


def ks_for(n):
    if n <= 6:
        return list(range(1, n + 1))
    ks = [k for k in [1, 2, 4, 8, 16, 32, 64] if k < n]
    return ks + [n]


def run_source(name, src, others, groups, ks, a, fsets, ckpt):
    feat_cols = [c for c in src.columns if "__" in c]
    done = set()
    if os.path.exists(ckpt):
        d = pd.read_csv(ckpt, usecols=["experiment", "seed", "k"])
        done = set(map(tuple, d[d.experiment == name][["seed", "k"]].values))
    exp_id = sum(map(ord, name))
    for seed in range(a.seeds):
        s_tr, s_te = train_test_split(src, test_size=0.3, random_state=seed,
                                      stratify=src["label"])
        tests = {"source": s_te}
        for tname, tdf in others.items():
            tests[tname] = train_test_split(tdf, test_size=0.3, random_state=seed,
                                            stratify=tdf["label"])[1]
        ben_tr = s_tr[s_tr.label == "benign"]
        att_tr = s_tr[s_tr.label != "benign"]
        for k in ks:
            if (seed, k) in done:
                print(f"  [{name}] seed {seed} k={k}: уже есть, пропуск", flush=True)
                continue
            rng = np.random.default_rng([seed, k, exp_id])
            combos = pick_combos(groups, k, a.max_combos, rng)
            rows = []
            for combo in combos:
                ben, rep = sample_groups(ben_tr, combo, a.n_benign, rng)
                att = att_tr.loc[rng.choice(att_tr.index.values, a.n_benign,
                                            replace=len(att_tr) < a.n_benign)]
                tr = pd.concat([ben, att])
                for fs in fsets:
                    cols = columns_for(fs, feat_cols)
                    sc = StandardScaler().fit(tr[cols].values)
                    Xtr, ytr = sc.transform(tr[cols].values), tr["is_attack"].values
                    for mname, fac in models(seed).items():
                        m = fac().fit(Xtr, ytr)
                        for where, te in tests.items():
                            y = te["is_attack"].values
                            yhat = m.predict(sc.transform(te[cols].values))
                            row = dict(experiment=name, seed=seed, k=k,
                                       n_groups=len(groups),
                                       groups="|".join(map(str, combo)),
                                       resampled=rep, feature_set=fs, model=mname,
                                       eval_on=where,
                                       false_alarm=float(yhat[y == 0].mean()),
                                       detection=float(yhat[y == 1].mean()),
                                       f1_prev10=f1_at(y, yhat))
                            for lab in sorted(te["label"].unique()):
                                if lab != "benign":
                                    mk = te["label"].values == lab
                                    row[f"det_{lab}"] = float(yhat[mk].mean())
                            rows.append(row)
            pd.DataFrame(rows).to_csv(ckpt, mode="a", index=False,
                                      header=not os.path.exists(ckpt))
            print(f"  [{name}] seed {seed} k={k}: {len(combos)} комбинаций, сохранено",
                  flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="results_diversity3")
    ap.add_argument("--sources", default="EdgeIIoT:file,CICIoT2023:host:192.168.137.,"
                                         "Gotham:file,Gotham:type")
    ap.add_argument("--keep", default="benign,ddos_syn,portscan")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--n-benign", type=int, default=5000)
    ap.add_argument("--max-combos", type=int, default=4)
    ap.add_argument("--min-group-flows", type=int, default=100)
    ap.add_argument("--feature-sets", default="FS1_base")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    keep = a.keep.split(",")
    fsets = a.feature_sets.split(",")

    data = {}
    for fn in sorted(glob.glob(os.path.join(a.data, "features_*.parquet"))):
        d = pd.read_parquet(fn)
        d = d[d["label"].isin(keep)].reset_index(drop=True)
        data[d["dataset"].iloc[0]] = d
        print(d["dataset"].iloc[0], d["label"].value_counts().to_dict())

    ckpt = os.path.join(a.out, "diversity_partial.csv")
    ginfo = []
    for spec in a.sources.split(","):
        parts = spec.split(":")
        ds, mode = parts[0], parts[1]
        prefix = parts[2] if len(parts) > 2 else ""
        if ds not in data:
            print(f"нет датасета {ds}, пропуск")
            continue
        src, groups = assign_groups(data[ds], mode, prefix, a.min_group_flows)
        name = f"{ds}[{mode}]"
        ks = ks_for(len(groups))
        print(f"{name}: групп {len(groups)}, k = {ks}", flush=True)
        for g in groups:
            ginfo.append([name, g, int((src["group"] == g).sum())])
        others = {k: v for k, v in data.items() if k != ds}
        run_source(name, src, others, groups, ks, a, fsets, ckpt)

    pd.DataFrame(ginfo, columns=["source", "group", "benign_flows"]).to_csv(
        os.path.join(a.out, "benign_groups.csv"), index=False)
    res = pd.read_csv(ckpt)
    res.to_csv(os.path.join(a.out, "diversity_results.csv"), index=False)

    stats = []
    tgt = res[res.eval_on != "source"]
    for key, g in tgt.groupby(["experiment", "eval_on", "model", "feature_set"]):
        for metric in ["false_alarm", "detection", "f1_prev10"]:
            gg = g.dropna(subset=[metric])
            if gg["k"].nunique() < 3:
                continue
            r, p = spearmanr(gg["k"], gg[metric])
            mk = gg.groupby("k")[metric].mean()
            rm, pm = spearmanr(mk.index, mk.values)
            stats.append(dict(zip(["experiment", "target", "model", "feature_set"], key),
                              metric=metric, rho_runs=r, p_runs=p, n_runs=len(gg),
                              rho_kmeans=rm, p_kmeans=pm, n_k=len(mk),
                              at_kmin=mk.iloc[0], at_kmax=mk.iloc[-1]))
    st = pd.DataFrame(stats)
    st.to_csv(os.path.join(a.out, "diversity_spearman.csv"), index=False)
    print(st[st.metric == "false_alarm"].round(3).to_string(index=False))
    print("сохранено в", a.out)


if __name__ == "__main__":
    main()

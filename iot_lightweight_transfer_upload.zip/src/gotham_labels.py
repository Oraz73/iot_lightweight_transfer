"""Сжатие пакетной разметки Gotham (processed/*.csv) до таблицы
(устройство, пара IP, протокол, секунда) -> число вредоносных пакетов,
всего пакетов и метка атаки. CSV читаются потоком, целиком не хранятся.

Результат: <out> (parquet) с колонками
  device, a, b, proto, sec, n_mal, n_tot, mal_label
где a < b - IP-адреса пары, sec - секунды UNIX (UTC).
"""
import argparse
import io
import os
import zipfile

import numpy as np
import pandas as pd

COLS = ["frame.time", "ip.src", "ip.dst", "ip.proto", "label"]


def open_zip(src):
    if os.path.exists(src):
        return zipfile.ZipFile(src)
    from remotezip import RemoteZip
    return RemoteZip(src)


def parse_sec(t):
    # 'Jan 14, 2025 18:44:53.420758000 GMT' -> секунды UNIX
    s = t.astype(str).str.replace(r"\.\d+", "", regex=True).str.replace(
        " GMT", "", regex=False)
    dt = pd.to_datetime(s, format="%b %d, %Y %H:%M:%S", utc=True, errors="coerce")
    # деление на 1 с не зависит от внутренней единицы времени pandas (нс/мкс/с)
    return (dt - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(seconds=1)


def aggregate(fh, device, chunksize):
    parts = []
    reader = pd.read_csv(io.TextIOWrapper(fh), usecols=COLS,
                         chunksize=chunksize, low_memory=False)
    n = 0
    for ch in reader:
        n += len(ch)
        ch = ch.dropna(subset=["ip.src", "ip.dst", "ip.proto"])
        if ch.empty:
            continue
        sec = parse_sec(ch["frame.time"])
        src, dst = ch["ip.src"].astype(str), ch["ip.dst"].astype(str)
        d = pd.DataFrame({
            "a": np.where(src < dst, src, dst),
            "b": np.where(src < dst, dst, src),
            "proto": pd.to_numeric(ch["ip.proto"], errors="coerce"),
            "sec": sec,
            "label": ch["label"].astype(str),
        }).dropna()
        d["mal"] = (~d["label"].str.lower().eq("benign")).astype(int)
        g = d.groupby(["a", "b", "proto", "sec", "label"]).size().rename("n")
        parts.append(g.reset_index())
        print(f"   {device}: прочитано {n:,} пакетов", flush=True)
    if not parts:
        return pd.DataFrame()
    g = pd.concat(parts).groupby(["a", "b", "proto", "sec", "label"])["n"].sum().reset_index()
    g["mal"] = ~g["label"].str.lower().eq("benign")
    tot = g.groupby(["a", "b", "proto", "sec"])["n"].sum().rename("n_tot")
    mal = g[g.mal].groupby(["a", "b", "proto", "sec"])["n"].sum().rename("n_mal")
    lab = (g[g.mal].sort_values("n").groupby(["a", "b", "proto", "sec"])["label"]
             .last().rename("mal_label"))
    out = pd.concat([tot, mal, lab], axis=1).reset_index()
    out["n_mal"] = out["n_mal"].fillna(0).astype(int)
    out["mal_label"] = out["mal_label"].fillna("")
    out["device"] = device
    out["proto"] = out["proto"].astype(int)
    out["sec"] = out["sec"].astype("int64")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="URL или путь к zip")
    ap.add_argument("--devices", required=True, help="через запятую")
    ap.add_argument("--out", required=True)
    ap.add_argument("--chunksize", type=int, default=500000)
    a = ap.parse_args()
    done = pd.read_parquet(a.out) if os.path.exists(a.out) else pd.DataFrame()
    have = set(done["device"]) if len(done) else set()
    res = [done] if len(done) else []
    with open_zip(a.src) as zf:
        for dev in a.devices.split(","):
            if dev in have:
                print(f"{dev}: уже размечено, пропуск")
                continue
            member = f"processed/iotsim-{dev}.csv"
            with zf.open(member) as fh:
                agg = aggregate(fh, dev, a.chunksize)
            print(f"{dev}: ключей {len(agg):,}, вредоносных пакетов "
                  f"{int(agg['n_mal'].sum()) if len(agg) else 0:,}")
            if len(agg):
                print("   метки атак:", agg.loc[agg.n_mal > 0, "mal_label"]
                      .value_counts().to_dict())
            res.append(agg)
            pd.concat(res, ignore_index=True).to_parquet(a.out, index=False)


if __name__ == "__main__":
    main()

"""Потоки и признаки для Gotham 2025 с разметкой по пакетным меткам авторов.

Нормальный трафик: каждый файл <raw>/benign/<device>.pcap -> label=benign,
src_file=<device> (группа для эксперимента на разнообразие).

Атаки: <raw>/<scenario>/<device>.pcap. Поток считается атакой, если среди
пакетов той же пары IP и протокола в секунды, которые он охватывает, доля
помеченных авторами как вредоносные >= --mal-thr; фоном (отбрасывается),
если <= --ben-thr; смешанные потоки тоже отбрасываются.
Класс атаки:
  network-scanning -> portscan (TCP) | udpscan (UDP) | scan_other
  merlin + метка содержит dos/flood -> ddos_syn | ddos_ack | ddos_udp | ddos_icmp
  остальное из merlin (C&C и т.п.) -> c2
Сдвиг часов между CSV и PCAP подбирается автоматически (целые часы).
"""
import argparse
import glob
import os

import numpy as np
import pandas as pd
from nfstream import NFStreamer

from features import compute_feature_groups


def extract(path, idle, active):
    return NFStreamer(source=path, statistical_analysis=True,
                      idle_timeout=idle, active_timeout=active,
                      n_dissections=0, splt_analysis=0).to_pandas()


def build_index(lab):
    """(a, b, proto) -> {sec: (n_mal, n_tot, label)}"""
    idx = {}
    for r in lab.itertuples(index=False):
        idx.setdefault((r.a, r.b, int(r.proto)), {})[int(r.sec)] = (
            r.n_mal, r.n_tot, r.mal_label)
    return idx


def flow_keys(f):
    s, d = f["src_ip"].astype(str).values, f["dst_ip"].astype(str).values
    a = np.where(s < d, s, d)
    b = np.where(s < d, d, s)
    return list(zip(a, b, f["protocol"].astype(int).values))


def lookup(idx, key, t0, t1):
    secs = idx.get(key)
    if not secs:
        return 0, 0, ""
    m = t = 0
    labs = {}
    for sec in range(t0, t1 + 1):
        v = secs.get(sec)
        if v:
            m += v[0]
            t += v[1]
            if v[0]:
                labs[v[2]] = labs.get(v[2], 0) + v[0]
    return m, t, (max(labs, key=labs.get) if labs else "")


def best_offset(f, idx, sample=3000, hours=range(-14, 15)):
    keys = flow_keys(f)
    t0 = (f["bidirectional_first_seen_ms"] // 1000).astype("int64").values
    t1 = (f["bidirectional_last_seen_ms"] // 1000).astype("int64").values
    pick = np.random.default_rng(0).choice(len(f), min(sample, len(f)), replace=False)
    best, rate = 0, -1.0
    for h in hours:
        off = h * 3600
        hit = sum(lookup(idx, keys[i], t0[i] + off, t1[i] + off)[1] > 0 for i in pick)
        if hit / len(pick) > rate:
            best, rate = off, hit / len(pick)
    return best, rate


def attack_class(scen, proto, mal_label, syn_frac, ack_frac):
    if scen == "network-scanning":
        return {6: "portscan", 17: "udpscan"}.get(proto, "scan_other")
    lab = mal_label.lower()
    if "dos" in lab or "flood" in lab:
        if proto == 6:
            return "ddos_syn" if syn_frac >= 0.5 and ack_frac < 0.5 else "ddos_ack"
        return {17: "ddos_udp", 1: "ddos_icmp"}.get(proto, "ddos_other")
    return "c2"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--out", default="data")
    ap.add_argument("--dataset", default="Gotham")
    ap.add_argument("--max-flows-per-file", type=int, default=50000)
    ap.add_argument("--idle-timeout", type=int, default=30)
    ap.add_argument("--active-timeout", type=int, default=10)
    ap.add_argument("--mal-thr", type=float, default=0.9)
    ap.add_argument("--ben-thr", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    labels = pd.read_parquet(a.labels)
    parts, log = [], []

    def finish(f, label_col, path, scen):
        if len(f) > a.max_flows_per_file:
            f = f.iloc[rng.choice(len(f), a.max_flows_per_file, replace=False)]
        f = f.reset_index(drop=True)
        g = compute_feature_groups(f)
        g["dataset"] = a.dataset
        g["label"] = label_col if isinstance(label_col, str) else f["_cls"].values
        g["is_attack"] = (g["label"] != "benign").astype(int)
        g["src_file"] = os.path.splitext(os.path.basename(path))[0]
        g["scenario"] = scen
        g["src_ip"] = f["src_ip"].values
        g["dst_ip"] = f["dst_ip"].values
        parts.append(g)

    for path in sorted(glob.glob(os.path.join(a.raw, "benign", "*.pcap"))):
        f = extract(path, a.idle_timeout, a.active_timeout)
        log.append(["benign", os.path.basename(path), len(f), len(f), ""])
        if len(f):
            finish(f, "benign", path, "benign")
    nb = sum(len(p) for p in parts)
    print(f"нормальный трафик: {len(parts)} устройств, {nb:,} потоков", flush=True)

    for scen in ["network-scanning", "merlin"]:
        for path in sorted(glob.glob(os.path.join(a.raw, scen, "*.pcap"))):
            dev = os.path.splitext(os.path.basename(path))[0]
            lab = labels[labels.device == dev]
            if lab.empty:
                print(f"{scen}/{dev}: нет разметки, пропуск")
                continue
            f = extract(path, a.idle_timeout, a.active_timeout)
            if f.empty:
                continue
            idx = build_index(lab)
            off, rate = best_offset(f, idx)
            keys = flow_keys(f)
            t0 = (f["bidirectional_first_seen_ms"] // 1000).astype("int64").values + off
            t1 = (f["bidirectional_last_seen_ms"] // 1000).astype("int64").values + off
            # флаги считаем только в направлении от инициатора потока: ответы
            # жертвы (SYN-ACK, RST-ACK) не должны превращать SYN-флуд в ACK-флуд
            pk = f["src2dst_packets"].clip(lower=1).values
            syn = f["src2dst_syn_packets"].values / pk
            ack = f["src2dst_ack_packets"].values / pk
            cls, keep = [], []
            n_unm = n_bg = n_mix = 0
            for i, k in enumerate(keys):
                m, t, ml = lookup(idx, k, t0[i], t1[i])
                if t == 0:
                    n_unm += 1
                    continue
                fr = m / t
                if fr >= a.mal_thr:
                    keep.append(i)
                    cls.append(attack_class(scen, k[2], ml, syn[i], ack[i]))
                elif fr <= a.ben_thr:
                    n_bg += 1
                else:
                    n_mix += 1
            print(f"{scen}/{dev}: потоков {len(f)}, сдвиг часов {off//3600:+d} ч "
                  f"(совпало {rate:.0%}); атака {len(keep)}, фон {n_bg}, "
                  f"смешанные {n_mix}, без разметки {n_unm}", flush=True)
            log.append([scen, dev, len(f), len(keep), f"{off//3600:+d}h"])
            if keep:
                fk = f.iloc[keep].copy()
                fk["_cls"] = cls
                for c, grp in fk.groupby("_cls"):
                    finish(grp, None, path, scen)

    df = pd.concat(parts, ignore_index=True)
    os.makedirs(a.out, exist_ok=True)
    fn = os.path.join(a.out, f"features_{a.dataset}.parquet")
    df.to_parquet(fn, index=False)
    pd.DataFrame(log, columns=["scenario", "file", "flows_raw", "flows_kept",
                               "clock_offset"]).to_csv(
        os.path.join(a.out, f"filter_log_{a.dataset}.csv"), index=False)
    print(f"{a.dataset}: {len(df):,} потоков -> {fn}")
    print(df.groupby("label").size().to_string())


if __name__ == "__main__":
    main()

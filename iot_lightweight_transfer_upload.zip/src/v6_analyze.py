"""Анализ v6: таблицы для статьи и график «внутри датасета / перенос / ресурсы»."""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

SURF, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
COL = {"DT": "#52514e", "MLP_S": "#2a78d6", "MLP_M": "#eb6834", "CNN1D": "#1baf7a",
       "AE": "#6250d6"}
ORDER = ["DT", "MLP_S", "MLP_M", "CNN1D", "AE"]


def boot(x, n=5000, seed=0):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return np.nan, np.nan
    m = np.random.default_rng(seed).choice(x, (n, len(x))).mean(axis=1)
    return np.quantile(m, 0.025), np.quantile(m, 0.975)


def style(ax):
    ax.set_facecolor(SURF)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    for s in ["left", "bottom"]:
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.yaxis.grid(True, color=GRID, lw=0.8)
    ax.set_axisbelow(True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="results_v6")
    a = ap.parse_args()
    r = pd.read_csv(os.path.join(a.dir, "v6_results.csv"))
    res = pd.read_csv(os.path.join(a.dir, "v6_resources.csv"))
    models = [m for m in ORDER if m in r.model.unique()]

    # T1: внутри датасета против переноса
    rows = []
    for (m, p), g in r.groupby(["model", "precision"]):
        ind, cr = g[g.in_domain], g[~g.in_domain]
        lo, hi = boot(cr["f1_prev10"])
        rows.append(dict(model=m, precision=p,
                         f1_in_domain=ind.f1_prev10.mean(),
                         f1_cross=cr.f1_prev10.mean(), f1_cross_ci_low=lo,
                         f1_cross_ci_high=hi, gap=ind.f1_prev10.mean() - cr.f1_prev10.mean(),
                         false_alarm_cross=cr.false_alarm.mean(),
                         detection_cross=cr.detection.mean()))
    t1 = pd.DataFrame(rows)
    t1["model"] = pd.Categorical(t1.model, ORDER, ordered=True)
    t1 = t1.sort_values(["model", "precision"])
    t1.round(3).to_csv(os.path.join(a.dir, "T1_in_vs_cross.csv"), index=False)

    # T2: цена квантования (int8 - fp32), парно по (сид, источник, цель)
    rows = []
    for m in models:
        g = r[r.model == m]
        if set(g.precision) != {"fp32", "int8"}:
            continue
        pv = g.pivot_table(index=["seed", "source", "target"], columns="precision",
                           values="f1_prev10")
        for scope, sel in [("внутри", pv.index.get_level_values("source") ==
                            pv.index.get_level_values("target")),
                           ("перенос", pv.index.get_level_values("source") !=
                            pv.index.get_level_values("target"))]:
            dlt = (pv["int8"] - pv["fp32"])[sel].dropna()
            lo, hi = boot(dlt)
            try:
                p = wilcoxon(dlt, zero_method="zsplit").pvalue if np.any(dlt != 0) else 1.0
            except ValueError:
                p = np.nan
            rows.append(dict(model=m, scope=scope, delta_f1_int8_minus_fp32=dlt.mean(),
                             ci_low=lo, ci_high=hi, max_abs=dlt.abs().max(),
                             p_wilcoxon=p, n=len(dlt)))
    t2 = pd.DataFrame(rows)
    t2.round(4).to_csv(os.path.join(a.dir, "T2_quantization_cost.csv"), index=False)

    # T3: ресурсы
    t3 = (res.groupby(["model", "precision"])
             .agg(n_params=("n_params", "mean"), size_kb=("size_bytes", lambda s: s.mean() / 1024),
                  latency_us=("latency_us", "median")).reset_index())
    t3["model"] = pd.Categorical(t3.model, ORDER, ordered=True)
    t3 = t3.sort_values(["model", "precision"])
    t3.round(2).to_csv(os.path.join(a.dir, "T3_resources.csv"), index=False)

    # T4: ранги моделей внутри датасета и при переносе (fp32)
    f = t1[t1.precision == "fp32"].set_index("model")
    t4 = pd.DataFrame({"rank_in_domain": f.f1_in_domain.rank(ascending=False),
                       "rank_cross": f.f1_cross.rank(ascending=False)})
    t4.to_csv(os.path.join(a.dir, "T4_ranks.csv"))

    # рисунок
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.9), facecolor=SURF)
    ax = axes[0]
    style(ax)
    x = np.arange(len(models))
    f32 = t1[t1.precision == "fp32"].set_index("model").reindex(models)
    i8 = t1[t1.precision == "int8"].set_index("model").reindex(models)
    ax.bar(x - 0.2, f32.f1_in_domain, 0.38, color="#c3c2b7", label="внутри датасета (fp32)",
           edgecolor=SURF)
    ax.bar(x + 0.2, f32.f1_cross, 0.38, color=[COL[m] for m in models],
           label="перенос (fp32)", edgecolor=SURF)
    ax.plot(x + 0.2, i8.f1_cross, "D", color=INK, ms=5, label="перенос (int8)")
    ax.set_xticks(x, models, color=INK2)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("F1 при 10% атак", color=INK2, fontsize=8)
    ax.set_title("Точность внутри датасета не предсказывает перенос", color=INK,
                 loc="left", fontsize=9)
    ax.legend(frameon=False, fontsize=7, loc="lower left")
    ax = axes[1]
    style(ax)
    ax.xaxis.grid(True, color=GRID, lw=0.8)
    for m in models:
        for p, mk in [("fp32", "o"), ("int8", "D")]:
            s = t3[(t3.model == m) & (t3.precision == p)]
            c = t1[(t1.model == m) & (t1.precision == p)]
            if len(s) and len(c):
                ax.plot(s.size_kb, c.f1_cross, mk, color=COL[m], ms=8, mec=SURF, mew=1.5,
                        label=f"{m} {p}")
    ax.set_xscale("log")
    ax.set_xlabel("размер модели, КБ (файл TFLite; DT - pickle)", color=INK2, fontsize=8)
    ax.set_ylabel("F1 при переносе", color=INK2, fontsize=8)
    ax.set_title("Размер против качества переноса", color=INK, loc="left", fontsize=9)
    ax.legend(frameon=False, fontsize=6, ncol=2)
    fig.tight_layout()
    fig.savefig(os.path.join(a.dir, "fig_v6_models.png"), dpi=200)
    plt.close(fig)
    pd.set_option("display.width", 200)
    print(t1.round(3).to_string(index=False))
    print(t2.round(4).to_string(index=False))
    print(t3.round(2).to_string(index=False))
    print(t4.to_string())


if __name__ == "__main__":
    main()

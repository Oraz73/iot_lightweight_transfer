"""Анализ результатов: таблицы, статистические контрасты, сдвиг распределений, графики.

Единица статистического анализа - (модель, источник, цель) для кросс-датасетных
пар; метрика сначала усредняется по сидам, затем к парным разностям применяется
критерий Уилкоксона с поправкой Холма и бутстрап-ДИ для среднего.
"""
import argparse
import glob
import os
from itertools import combinations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp, wilcoxon

from features import FEATURE_SETS, GROUPS

SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#6250d6"]  # синий, оранжевый, аква, фиолетовый

CONTRASTS = [  # (название, A, B): разность = A - B
    ("форма времени vs абсолютное время", "FS4_base+shape", "FS2_base+raw"),
    ("абсолютное время vs без времени", "FS2_base+raw", "FS1_base"),
    ("форма времени vs без времени", "FS4_base+shape", "FS1_base"),
    ("интенсивность vs без времени", "FS3_base+rate", "FS1_base"),
    ("всё время vs форма времени", "FS5_base+alltime", "FS4_base+shape"),
    ("добавление портов", "FS6_alltime+ports", "FS5_base+alltime"),
]


def style(ax):
    ax.set_facecolor(SURFACE)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    for s in ["left", "bottom"]:
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=9)
    ax.yaxis.grid(True, color=GRID, lw=0.8)
    ax.set_axisbelow(True)


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    run = 0
    for i, k in enumerate(order):
        run = max(run, (len(p) - i) * p[k])
        adj[k] = min(1.0, run)
    return adj


def boot_ci(x, n=5000, seed=0):
    rng = np.random.default_rng(seed)
    m = rng.choice(x, (n, len(x)), replace=True).mean(axis=1)
    return np.quantile(m, [0.025, 0.975])


def contrasts(res, metric, prevalence):
    r = res[(~res.in_domain) & (res.prevalence == prevalence)]
    g = r.groupby(["model", "source", "target", "feature_set"])[metric].mean().unstack()
    rows = []
    for name, a, b in CONTRASTS:
        if a not in g or b not in g:
            continue
        d = (g[a] - g[b]).dropna().values
        if len(d) < 2:
            continue
        try:
            p = wilcoxon(d, zero_method="zsplit").pvalue if np.any(d != 0) else 1.0
        except ValueError:
            p = np.nan
        lo, hi = boot_ci(d)
        rows.append(dict(contrast=name, A=a, B=b, n_units=len(d), mean_diff=d.mean(),
                         median_diff=np.median(d), ci95_low=lo, ci95_high=hi,
                         wins=int((d > 0).sum()), losses=int((d < 0).sum()), p=p))
    out = pd.DataFrame(rows)
    if len(out):
        out["p_holm"] = holm(out["p"].fillna(1).values)
    return out


def shift_analysis(data_dir, max_n=20000, seed=0):
    """KS-статистика между датасетами для каждого признака, отдельно для
    нормального трафика и для атак. Чем больше KS, тем сильнее признак
    'привязан' к конкретному стенду."""
    dfs = {}
    for fn in sorted(glob.glob(os.path.join(data_dir, "features_*.parquet"))):
        d = pd.read_parquet(fn)
        dfs[d["dataset"].iloc[0]] = d
    cols = [c for c in next(iter(dfs.values())).columns if "__" in c]
    rng = np.random.default_rng(seed)
    rows = []
    for cls, cname in [(0, "benign"), (1, "attack")]:
        sub = {}
        for k, d in dfs.items():
            x = d[d.is_attack == cls]
            if len(x) > max_n:
                x = x.iloc[rng.choice(len(x), max_n, replace=False)]
            sub[k] = x
        for a, b in combinations(sub, 2):
            if len(sub[a]) == 0 or len(sub[b]) == 0:
                continue
            for c in cols:
                ks = ks_2samp(sub[a][c].values, sub[b][c].values).statistic
                rows.append(dict(cls=cname, pair=f"{a}~{b}", feature=c,
                                 group=c.split("__")[0], ks=ks))
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--data", default="data")
    ap.add_argument("--prevalence", default="0.1")
    ap.add_argument("--metric", default="f1")
    a = ap.parse_args()
    R = a.results
    res = pd.read_csv(os.path.join(R, "results.csv"), dtype={"prevalence": str})
    pv, met = a.prevalence, a.metric
    fs_order = list(FEATURE_SETS)
    models = [m for m in ["DT", "MLP_S", "MLP_M", "AE"] if m in res.model.unique()]

    # 1. Сводная таблица: внутри домена / между датасетами / разрыв
    r = res[res.prevalence == pv]
    summ = (r.groupby(["model", "feature_set", "in_domain"])[met].mean()
             .unstack().rename(columns={True: "in_domain", False: "cross_domain"}))
    summ["gap"] = summ["in_domain"] - summ["cross_domain"]
    summ = summ.reset_index()
    summ.to_csv(os.path.join(R, f"summary_{met}_prev{pv}.csv"), index=False)

    # 2. Статистические контрасты
    con = contrasts(res, met, pv)
    con.to_csv(os.path.join(R, f"contrasts_{met}_prev{pv}.csv"), index=False)
    for mdl in models:
        cm = contrasts(res[res.model == mdl], met, pv)
        cm.insert(0, "model", mdl)
        cm.to_csv(os.path.join(R, f"contrasts_{met}_prev{pv}_{mdl}.csv"), index=False)

    # 3. Сдвиг распределений
    sh = shift_analysis(a.data)
    sh.to_csv(os.path.join(R, "shift_ks_per_feature.csv"), index=False)
    shg = sh.groupby(["cls", "group"])["ks"].mean().unstack(0).reindex(GROUPS)
    shg.to_csv(os.path.join(R, "shift_ks_per_group.csv"))

    # ---- График 1: кросс-датасетный F1 по наборам признаков ----
    fig, ax = plt.subplots(figsize=(9, 4.2), facecolor=SURFACE)
    style(ax)
    cross = summ.pivot(index="feature_set", columns="model", values="cross_domain").reindex(fs_order)
    w = 0.8 / len(models)
    x = np.arange(len(fs_order))
    for i, mdl in enumerate(models):
        ax.bar(x + (i - (len(models) - 1) / 2) * w, cross[mdl].values, w * 0.9,
               color=SERIES[i], label=mdl, edgecolor=SURFACE, linewidth=1)
    ax.set_xticks(x, [f.split("_", 1)[1] for f in fs_order], rotation=15, color=INK2)
    ax.set_ylabel(f"{met.upper()} между датасетами (атаки = {pv})", color=INK2)
    ax.set_title("Перенос на чужой датасет без дообучения", color=INK, loc="left", fontsize=11)
    ax.legend(frameon=False, fontsize=9, ncol=len(models), loc="upper left",
              bbox_to_anchor=(0, -0.18))
    fig.tight_layout()
    fig.savefig(os.path.join(R, "fig1_cross_domain_by_featureset.png"), dpi=200)
    plt.close(fig)

    # ---- График 2: контрасты со 95% ДИ ----
    if len(con):
        fig, ax = plt.subplots(figsize=(8, 0.55 * len(con) + 1.2), facecolor=SURFACE)
        style(ax)
        ax.yaxis.grid(False)
        ax.xaxis.grid(True, color=GRID, lw=0.8)
        y = np.arange(len(con))[::-1]
        ax.axvline(0, color=INK2, lw=1)
        ax.hlines(y, con.ci95_low, con.ci95_high, color=SERIES[0], lw=2)
        ax.plot(con.mean_diff, y, "o", ms=8, color=SERIES[0], mec=SURFACE, mew=2)
        lbl = [f"{c}  (p_holm={p:.3g})" for c, p in zip(con.contrast, con.p_holm)]
        ax.set_yticks(y, lbl, color=INK)
        ax.set_xlabel(f"Δ {met.upper()} между датасетами (A − B), среднее и 95% ДИ", color=INK2)
        fig.tight_layout()
        fig.savefig(os.path.join(R, "fig2_contrasts.png"), dpi=200)
        plt.close(fig)

    # ---- График 3: сдвиг распределений по группам признаков ----
    fig, ax = plt.subplots(figsize=(7.5, 3.8), facecolor=SURFACE)
    style(ax)
    xg = np.arange(len(GROUPS))
    for i, cls in enumerate([c for c in ["benign", "attack"] if c in shg]):
        ax.bar(xg + (i - 0.5) * 0.38, shg[cls].values, 0.36, color=SERIES[i],
               label={"benign": "нормальный трафик", "attack": "атаки"}[cls],
               edgecolor=SURFACE, linewidth=1)
    ax.set_xticks(xg, GROUPS, color=INK2)
    ax.set_ylabel("Средняя KS-статистика между датасетами", color=INK2)
    ax.set_title("Насколько группа признаков 'привязана' к стенду", color=INK, loc="left", fontsize=11)
    ax.legend(frameon=False, fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(R, "fig3_shift_by_group.png"), dpi=200)
    plt.close(fig)

    # ---- Отчёт ----
    rs = pd.read_csv(os.path.join(R, "resource_estimate.csv"))
    with open(os.path.join(R, "REPORT.md"), "w", encoding="utf-8") as f:
        f.write(f"# Результаты (метрика {met}, доля атак в тесте {pv})\n\n")
        f.write("Датасеты: " + ", ".join(sorted(res.source.unique())) +
                f"; сидов: {res.seed.nunique()}; модели: {', '.join(models)}\n\n")
        f.write("## Внутри домена, между датасетами, разрыв\n\n")
        f.write(summ.round(3).to_markdown(index=False) + "\n\n")
        f.write("## Контрасты наборов признаков (все модели вместе)\n\n")
        f.write(con.round(4).to_markdown(index=False) + "\n\n")
        f.write("## Сдвиг распределений (средняя KS между датасетами)\n\n")
        f.write(shg.round(3).to_markdown() + "\n\n")
        f.write("## Аналитическая ресурсная оценка (НЕ измерение на железе)\n\n")
        f.write(rs.to_markdown(index=False) + "\n")
    print("готово:", R)


if __name__ == "__main__":
    main()

"""Два контрольных эксперимента v5.

А (volume): объём против разнообразия. Полный факторный план
   k (число групп нормального трафика) x V (число нормальных потоков) при
   обучении, БЕЗ повторения примеров: в ячейку (k, V) берутся только группы,
   в которых не меньше V/k потоков. Атак в обучении столько же, сколько
   нормальных потоков (баланс классов). Оценка - на всех чужих датасетах.

Б (adapt): протокол ввода в новую сеть. Модель обучается на сети-источнике
   (все группы, фиксированный объём). Затем в обучение добавляется ТОЛЬКО
   нормальный трафик (без меток атак) от k устройств целевой сети при
   фиксированном объёме n_t. Оценка - на нормальном трафике ДРУГИХ устройств
   целевой сети (не участвовавших в дообучении) и на всех её атаках.

Каждый блок сохраняется сразу; при перезапуске готовые блоки пропускаются.
"""
import argparse
import glob
import os
import warnings

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from diversity3 import assign_groups, f1_at, models, pick_combos
from features import columns_for

warnings.filterwarnings("ignore")

GROUPING = {  # датасет -> (способ, префикс) для групп нормального трафика
    "CICIoT2023": ("host", "192.168.137."),
    "EdgeIIoT": ("file", ""),
    "Gotham": ("file", ""),
}


def load(data_dir, keep):
    data = {}
    for fn in sorted(glob.glob(os.path.join(data_dir, "features_*.parquet"))):
        d = pd.read_parquet(fn)
        d = d[d["label"].isin(keep)].reset_index(drop=True)
        data[d["dataset"].iloc[0]] = d
    return data


def done_blocks(ckpt, keys):
    if not os.path.exists(ckpt):
        return set()
    d = pd.read_csv(ckpt, usecols=keys)
    return set(map(tuple, d[keys].astype(str).values))


def append(ckpt, rows):
    if rows:
        pd.DataFrame(rows).to_csv(ckpt, mode="a", index=False,
                                  header=not os.path.exists(ckpt))


def evaluate(m, sc, cols, te):
    y = te["is_attack"].values
    yhat = m.predict(sc.transform(te[cols].values))
    out = dict(false_alarm=float(yhat[y == 0].mean()) if (y == 0).any() else np.nan,
               detection=float(yhat[y == 1].mean()) if (y == 1).any() else np.nan,
               f1_prev10=f1_at(y, yhat), n_test=len(y))
    return out


def split_ds(df, seed):
    return train_test_split(df, test_size=0.3, random_state=seed, stratify=df["label"])


# ---------------------------------------------------------------- А: объём
def run_volume(a, data, fsets):
    ckpt = os.path.join(a.out, "volume_partial.csv")
    keys = ["source", "seed", "k", "V"]
    done = done_blocks(ckpt, keys)
    ks = [int(x) for x in a.ks.split(",")]
    vs = [int(x) for x in a.vs.split(",")]
    for src_spec in a.volume_sources.split(","):
        ds, mode = src_spec.split(":")[:2]
        prefix = src_spec.split(":")[2] if src_spec.count(":") >= 2 else ""
        if ds not in data:
            continue
        name = f"{ds}[{mode}]"
        src, groups = assign_groups(data[ds], mode, prefix, 1)
        others = {k: v for k, v in data.items() if k != ds}
        for seed in range(a.seeds):
            s_tr, _ = split_ds(src, seed)
            tests = {t: split_ds(v, seed)[1] for t, v in others.items()}
            ben_tr = s_tr[s_tr.label == "benign"]
            att_tr = s_tr[s_tr.label != "benign"]
            cnt = ben_tr["group"].value_counts()
            for k in ks:
                for V in vs:
                    if (name, str(seed), str(k), str(V)) in done:
                        continue
                    per = V // k
                    elig = sorted(cnt[cnt >= per].index)
                    if len(elig) < k or per < 1:
                        print(f"  [A {name}] seed {seed} k={k} V={V}: "
                              f"мало групп ({len(elig)}), пропуск", flush=True)
                        append(ckpt, [dict(source=name, seed=seed, k=k, V=V,
                                           skipped=True)])
                        continue
                    rng = np.random.default_rng([seed, k, V, sum(map(ord, name))])
                    rows = []
                    for combo in pick_combos(elig, k, a.max_combos, rng):
                        idx = np.concatenate([
                            rng.choice(ben_tr.index[ben_tr["group"] == g].values,
                                       per, replace=False) for g in combo])
                        ben = ben_tr.loc[idx]
                        att = att_tr.loc[rng.choice(att_tr.index.values, len(ben),
                                                    replace=len(att_tr) < len(ben))]
                        tr = pd.concat([ben, att])
                        for fs in fsets:
                            cols = columns_for(fs, [c for c in tr.columns if "__" in c])
                            sc = StandardScaler().fit(tr[cols].values)
                            X, y = sc.transform(tr[cols].values), tr["is_attack"].values
                            for mname, fac in models(seed).items():
                                m = fac().fit(X, y)
                                for t, te in tests.items():
                                    rows.append(dict(source=name, seed=seed, k=k, V=V,
                                                     skipped=False, target=t,
                                                     groups="|".join(map(str, combo)),
                                                     feature_set=fs, model=mname,
                                                     **evaluate(m, sc, cols, te)))
                    append(ckpt, rows)
                    print(f"  [A {name}] seed {seed} k={k} V={V}: сохранено", flush=True)
    res = pd.read_csv(ckpt)
    res = res[res["skipped"] != True]  # noqa: E712
    res.to_csv(os.path.join(a.out, "volume_results.csv"), index=False)
    return res


# ---------------------------------------------------------------- Б: адаптация
def run_adapt(a, data, fsets):
    ckpt = os.path.join(a.out, "adapt_partial.csv")
    keys = ["source", "target", "seed", "k_t"]
    done = done_blocks(ckpt, keys)
    kts = [int(x) for x in a.k_target.split(",")]
    grouped = {}
    for ds, (mode, prefix) in GROUPING.items():
        if ds in data:
            grouped[ds] = assign_groups(data[ds], mode, prefix, a.min_group_flows)
    for src_name in grouped:
        for tgt_name in grouped:
            if src_name == tgt_name:
                continue
            src, _ = grouped[src_name]
            tgt, tgroups = grouped[tgt_name]
            for seed in range(a.seeds):
                s_tr, _ = split_ds(src, seed)
                t_tr, t_te = split_ds(tgt, seed)
                ben_s = s_tr[s_tr.label == "benign"]
                att_s = s_tr[s_tr.label != "benign"]
                rng0 = np.random.default_rng([seed, 7])
                base_ben = ben_s.loc[rng0.choice(ben_s.index.values, a.n_source,
                                                 replace=len(ben_s) < a.n_source)]
                base_att = att_s.loc[rng0.choice(att_s.index.values, a.n_source,
                                                 replace=len(att_s) < a.n_source)]
                t_ben_tr = t_tr[t_tr.label == "benign"]
                t_att_te = t_te[t_te.label != "benign"]
                for k in kts:
                    if k > len(tgroups) - 1:  # нужна хотя бы одна отложенная группа
                        continue
                    if (src_name, tgt_name, str(seed), str(k)) in done:
                        continue
                    rng = np.random.default_rng([seed, k, sum(map(ord, src_name + tgt_name))])
                    combos = [()] if k == 0 else pick_combos(tgroups, k, a.max_combos, rng)
                    rows = []
                    for combo in combos:
                        add = pd.DataFrame()
                        if k:
                            per = max(1, a.n_target // k)
                            parts = []
                            for g in combo:
                                pool = t_ben_tr.index[t_ben_tr["group"] == g].values
                                parts.append(rng.choice(pool, per, replace=len(pool) < per))
                            add = t_ben_tr.loc[np.concatenate(parts)]
                        # нормальный трафик цели ЗАМЕНЯЕТ часть нормального трафика
                        # источника: общий объём и баланс классов не зависят от k
                        tr = pd.concat([base_ben.iloc[:a.n_source - len(add)], add,
                                        base_att])
                        held = t_te[(t_te.label == "benign") & ~t_te["group"].isin(combo)]
                        te = pd.concat([held, t_att_te])
                        for fs in fsets:
                            cols = columns_for(fs, [c for c in tr.columns if "__" in c])
                            sc = StandardScaler().fit(tr[cols].values)
                            X, y = sc.transform(tr[cols].values), tr["is_attack"].values
                            for mname, fac in models(seed).items():
                                m = fac().fit(X, y)
                                rows.append(dict(source=src_name, target=tgt_name,
                                                 seed=seed, k_t=k, n_target=a.n_target,
                                                 groups="|".join(map(str, combo)),
                                                 held_groups=held["group"].nunique(),
                                                 feature_set=fs, model=mname,
                                                 **evaluate(m, sc, cols, te)))
                    append(ckpt, rows)
                    print(f"  [Б {src_name}->{tgt_name}] seed {seed} k_t={k}: сохранено",
                          flush=True)
    res = pd.read_csv(ckpt)
    res.to_csv(os.path.join(a.out, "adapt_results.csv"), index=False)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("what", choices=["volume", "adapt"])
    ap.add_argument("--data", default="data3")
    ap.add_argument("--out", default="results_v5")
    ap.add_argument("--keep", default="benign,ddos_syn,portscan")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--max-combos", type=int, default=3)
    ap.add_argument("--feature-sets", default="FS1_base")
    # А
    ap.add_argument("--volume-sources",
                    default="CICIoT2023:host:192.168.137.,Gotham:type,EdgeIIoT:file")
    ap.add_argument("--ks", default="1,2,4,8")
    ap.add_argument("--vs", default="250,500,1000,2000")
    # Б
    ap.add_argument("--k-target", default="0,1,2,4,8")
    ap.add_argument("--n-target", type=int, default=1000)
    ap.add_argument("--n-source", type=int, default=5000)
    ap.add_argument("--min-group-flows", type=int, default=100)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    data = load(a.data, a.keep.split(","))
    fsets = a.feature_sets.split(",")
    if a.what == "volume":
        r = run_volume(a, data, fsets)
    else:
        r = run_adapt(a, data, fsets)
    print("строк:", len(r), "->", a.out)


if __name__ == "__main__":
    main()

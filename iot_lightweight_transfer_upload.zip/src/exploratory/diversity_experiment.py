"""Контролируемый эксперимент: разнообразие нормального трафика при обучении
и ложные тревоги при переносе на чужую сеть.

Нормальный трафик источника делится на "группы":
  * EdgeIIoT   - тип сенсора (файл PCAP: benign_1..benign_5);
  * CICIoT2023 - локальное устройство сети (IP 192.168.137.x).
Модель обучается на нормальном трафике k групп (k = 1, 2, ...) при
ФИКСИРОВАННОМ общем объёме нормальных примеров, поэтому меняется только
разнообразие, а не количество. Атаки в обучении одни и те же.

Измеряется на чужом датасете: доля ложных тревог на его нормальном
трафике, доля обнаруженных атак и F1 при 10% атак. Для контроля - те же
метрики внутри своего датасета.
"""
import argparse
import os
from itertools import combinations
from math import comb

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from features import FEATURE_SETS, columns_for

KEEP = ["benign", "ddos_syn", "ddos_http", "portscan"]


def local_host(df, prefix):
    s, d = df["src_ip"].astype(str), df["dst_ip"].astype(str)
    return np.where(s.str.startswith(prefix), s,
                    np.where(d.str.startswith(prefix), d, "other"))


def f1_at(y, yhat, prev=0.1):
    p = y.mean()
    w = np.where(y == 1, prev / p, (1 - prev) / (1 - p))
    return f1_score(y, yhat, sample_weight=w, zero_division=0)


def models(seed):
    return {
        "DT": lambda: DecisionTreeClassifier(max_depth=10, random_state=seed),
        "MLP_S": lambda: MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=200,
                                       early_stopping=True, random_state=seed),
    }


def pick_combos(groups, k, max_combos, rng, enum_limit=200000):
    """До max_combos разных комбинаций по k групп. Полный перебор - только
    если комбинаций немного; иначе случайные выборки без перечисления всех
    (C(42, 8) = 118 млн комбинаций не помещается в память)."""
    if comb(len(groups), k) <= enum_limit:
        allc = list(combinations(groups, k))
        if len(allc) <= max_combos:
            return allc
        pick = rng.choice(len(allc), max_combos, replace=False)
        return [allc[i] for i in pick]
    seen = set()
    while len(seen) < max_combos:
        seen.add(tuple(sorted(rng.choice(groups, k, replace=False))))
    return sorted(seen)


def sample_groups(ben, groups, n_total, rng):
    """Поровну из каждой группы; если в группе мало потоков - с повторением."""
    per = n_total // len(groups)
    idx, replaced = [], False
    for g in groups:
        pool = ben.index[ben["group"] == g].values
        rep = len(pool) < per
        replaced |= rep
        idx.append(rng.choice(pool, per, replace=rep))
    return ben.loc[np.concatenate(idx)], replaced


def run(name, src, tgt, ks, max_combos, seeds, n_ben, fsets, ckpt):
    """Результаты каждого блока (эксперимент, сид, k) сразу дописываются в
    ckpt; уже посчитанные блоки при перезапуске пропускаются."""
    feat_cols = [c for c in src.columns if "__" in c]
    done = set()
    if os.path.exists(ckpt):
        d = pd.read_csv(ckpt, usecols=["experiment", "seed", "k"])
        done = set(map(tuple, d[d.experiment == name][["seed", "k"]].values))
    exp_id = sum(map(ord, name))
    for seed in range(seeds):
        s_tr, s_te = train_test_split(src, test_size=0.3, random_state=seed,
                                      stratify=src["label"])
        _, t_te = train_test_split(tgt, test_size=0.3, random_state=seed,
                                   stratify=tgt["label"])
        ben_tr = s_tr[s_tr.label == "benign"]
        att_tr = s_tr[s_tr.label != "benign"]
        all_groups = sorted(ben_tr["group"].unique())
        for k in ks:
            if k > len(all_groups):
                continue
            if (seed, k) in done:
                print(f"  [{name}] seed {seed} k={k}: уже есть, пропуск", flush=True)
                continue
            rng = np.random.default_rng([seed, k, exp_id])
            out_rows = []
            combos = pick_combos(all_groups, k, max_combos, rng)
            for combo in combos:
                ben, rep = sample_groups(ben_tr, combo, n_ben, rng)
                att = att_tr.loc[rng.choice(att_tr.index.values, n_ben,
                                            replace=len(att_tr) < n_ben)]
                tr = pd.concat([ben, att])
                for fs in fsets:
                    cols = columns_for(fs, feat_cols)
                    sc = StandardScaler().fit(tr[cols].values)
                    Xtr, ytr = sc.transform(tr[cols].values), tr["is_attack"].values
                    for mname, fac in models(seed).items():
                        m = fac().fit(Xtr, ytr)
                        for where, te in [("target", t_te), ("source", s_te)]:
                            yhat = m.predict(sc.transform(te[cols].values))
                            y = te["is_attack"].values
                            row = dict(experiment=name, seed=seed, k=k,
                                       groups="|".join(map(str, combo)),
                                       resampled=rep, feature_set=fs,
                                       model=mname, eval_on=where,
                                       false_alarm=float(yhat[y == 0].mean()),
                                       detection=float(yhat[y == 1].mean()),
                                       f1_prev10=f1_at(y, yhat))
                            for lab in KEEP[1:]:
                                mk = te["label"].values == lab
                                if mk.any():
                                    row[f"det_{lab}"] = float(yhat[mk].mean())
                            out_rows.append(row)
            pd.DataFrame(out_rows).to_csv(ckpt, mode="a", index=False,
                                          header=not os.path.exists(ckpt))
            print(f"  [{name}] seed {seed} k={k}: {len(combos)} комбинаций, сохранено",
                  flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="results_diversity")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--n-benign", type=int, default=5000,
                    help="фиксированное число нормальных потоков в обучении")
    ap.add_argument("--max-combos", type=int, default=5)
    ap.add_argument("--min-host-flows", type=int, default=300)
    ap.add_argument("--feature-sets", default="FS1_base,FS5_base+alltime")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    edge = pd.read_parquet(os.path.join(a.data, "features_EdgeIIoT.parquet"))
    cic = pd.read_parquet(os.path.join(a.data, "features_CICIoT2023.parquet"))
    edge = edge[edge.label.isin(KEEP)].reset_index(drop=True)
    cic = cic[cic.label.isin(KEEP)].reset_index(drop=True)
    fsets = a.feature_sets.split(",")

    # группы нормального трафика
    edge["group"] = np.where(edge.label == "benign", edge["src_file"], "attack")
    cic["group"] = np.where(cic.label == "benign",
                            local_host(cic, "192.168.137."), "attack")
    cnt = cic.loc[cic.label == "benign", "group"].value_counts()
    good = cnt[(cnt >= a.min_host_flows) & (cnt.index != "other")].index
    cic = cic[(cic.label != "benign") | cic["group"].isin(good)].reset_index(drop=True)
    n_edge = edge.loc[edge.label == "benign", "group"].nunique()
    n_cic = len(good)
    print(f"Edge: типов сенсоров {n_edge}; CIC: устройств с >= "
          f"{a.min_host_flows} потоков {n_cic}")
    pd.concat([
        edge.loc[edge.label == "benign", "group"].value_counts().rename("flows")
            .to_frame().assign(dataset="EdgeIIoT"),
        cnt.loc[good].rename("flows").to_frame().assign(dataset="CICIoT2023"),
    ]).to_csv(os.path.join(a.out, "benign_groups.csv"))

    ckpt = os.path.join(a.out, "diversity_partial.csv")
    run("A_Edge_to_CIC", edge, cic, list(range(1, n_edge + 1)),
        a.max_combos, a.seeds, a.n_benign, fsets, ckpt)
    ks_cic = [k for k in [1, 2, 4, 8, 16, 32, 64] if k <= n_cic]
    if n_cic not in ks_cic:
        ks_cic.append(n_cic)
    run("B_CIC_to_Edge", cic, edge, ks_cic,
        a.max_combos, a.seeds, a.n_benign, fsets, ckpt)

    res = pd.read_csv(ckpt)
    res.to_csv(os.path.join(a.out, "diversity_results.csv"), index=False)

    # Спирмен: связь k с ложными тревогами и F1 на чужом датасете
    stats = []
    for (exp, mdl, fs), g in res[res.eval_on == "target"].groupby(
            ["experiment", "model", "feature_set"]):
        for metric in ["false_alarm", "f1_prev10", "detection"]:
            r, p = spearmanr(g["k"], g[metric])
            stats.append(dict(experiment=exp, model=mdl, feature_set=fs,
                              metric=metric, spearman_rho=r, p=p, n=len(g)))
    st = pd.DataFrame(stats)
    st.to_csv(os.path.join(a.out, "diversity_spearman.csv"), index=False)
    summ = (res.groupby(["experiment", "eval_on", "model", "feature_set", "k"])
              [["false_alarm", "detection", "f1_prev10"]].agg(["mean", "std"])
              .round(3))
    summ.to_csv(os.path.join(a.out, "diversity_summary.csv"))
    print(st.round(4).to_string(index=False))
    print("сохранено в", a.out)


if __name__ == "__main__":
    main()

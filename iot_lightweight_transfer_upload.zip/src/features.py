"""Единое извлечение потоковых признаков из PCAP и разбиение их на группы.

Все датасеты проходят через ОДИН экстрактор (NFStream), поэтому определения
признаков одинаковы. Это главное методологическое отличие от работ, которые
сравнивают признаки, посчитанные разными инструментами в разных датасетах.
"""
import numpy as np
import pandas as pd

EPS = 1e-9

# ---------------------------------------------------------------------------
# Группы признаков
# ---------------------------------------------------------------------------
# SIZE   - размеры и объём (задаются протоколом и поведением устройства)
# FLAGS  - доли TCP-флагов и протокол
# PORTS  - корзины портов (известный источник "коротких путей")
# T_RAW  - абсолютное время: длительность и межпакетные интервалы, мс
# T_RATE - абсолютная интенсивность: пакеты/с и байты/с
# T_SHAPE- безразмерная форма времени: инвариантна к масштабированию оси времени
GROUPS = ["SIZE", "FLAGS", "PORTS", "T_RAW", "T_RATE", "T_SHAPE"]

FEATURE_SETS = {
    "FS1_base":            ["SIZE", "FLAGS"],
    "FS2_base+raw":        ["SIZE", "FLAGS", "T_RAW"],
    "FS3_base+rate":       ["SIZE", "FLAGS", "T_RATE"],
    "FS4_base+shape":      ["SIZE", "FLAGS", "T_SHAPE"],
    "FS5_base+alltime":    ["SIZE", "FLAGS", "T_RAW", "T_RATE", "T_SHAPE"],
    "FS6_alltime+ports":   ["SIZE", "FLAGS", "T_RAW", "T_RATE", "T_SHAPE", "PORTS"],
}

META_COLS = ["dataset", "label", "is_attack", "src_file", "src_ip", "dst_ip"]


def _port_bucket(p):
    p = np.asarray(p, dtype=float)
    out = np.full(p.shape, "none", dtype=object)
    out[(p > 0) & (p < 1024)] = "wellknown"
    out[(p >= 1024) & (p < 49152)] = "registered"
    out[p >= 49152] = "dynamic"
    return out


def _burstiness(mean, std):
    """Коэффициент всплесков Го-Барабаши: (s-m)/(s+m) в [-1, 1]."""
    den = mean + std
    return np.where(den > EPS, (std - mean) / np.maximum(den, EPS), 0.0)


def compute_feature_groups(f: pd.DataFrame) -> pd.DataFrame:
    """f - DataFrame потоков NFStream (statistical_analysis=True)."""
    out = pd.DataFrame(index=f.index)
    pk = f["bidirectional_packets"].clip(lower=1).astype(float)
    by = f["bidirectional_bytes"].astype(float)

    # ---- SIZE ----
    out["SIZE__log_pkts"] = np.log1p(pk)
    out["SIZE__log_bytes"] = np.log1p(by)
    for c in ["min_ps", "mean_ps", "stddev_ps", "max_ps"]:
        out[f"SIZE__bi_{c}"] = f[f"bidirectional_{c}"].astype(float)
    out["SIZE__s2d_mean_ps"] = f["src2dst_mean_ps"].astype(float)
    out["SIZE__d2s_mean_ps"] = f["dst2src_mean_ps"].astype(float)
    out["SIZE__down_pkt_frac"] = f["dst2src_packets"] / pk
    out["SIZE__down_byte_frac"] = f["dst2src_bytes"] / by.clip(lower=1)
    out["SIZE__piat_defined"] = (pk >= 3).astype(float)

    # ---- FLAGS ----
    for fl in ["syn", "ack", "psh", "rst", "fin", "urg"]:
        out[f"FLAGS__{fl}_frac"] = f[f"bidirectional_{fl}_packets"] / pk
    proto = f["protocol"].astype(int)
    out["FLAGS__proto_tcp"] = (proto == 6).astype(float)
    out["FLAGS__proto_udp"] = (proto == 17).astype(float)
    out["FLAGS__proto_icmp"] = proto.isin([1, 58]).astype(float)
    out["FLAGS__proto_other"] = (~proto.isin([1, 6, 17, 58])).astype(float)

    # ---- PORTS ----
    for side in ["src", "dst"]:
        b = _port_bucket(f[f"{side}_port"])
        for k in ["none", "wellknown", "registered", "dynamic"]:
            out[f"PORTS__{side}_{k}"] = (b == k).astype(float)

    # ---- T_RAW (абсолютное время, мс) ----
    out["T_RAW__log_dur_ms"] = np.log1p(f["bidirectional_duration_ms"].astype(float))
    for c in ["min_piat_ms", "mean_piat_ms", "stddev_piat_ms", "max_piat_ms"]:
        out[f"T_RAW__log_bi_{c}"] = np.log1p(f[f"bidirectional_{c}"].astype(float).clip(lower=0))
    out["T_RAW__log_s2d_mean_piat"] = np.log1p(f["src2dst_mean_piat_ms"].astype(float).clip(lower=0))
    out["T_RAW__log_d2s_mean_piat"] = np.log1p(f["dst2src_mean_piat_ms"].astype(float).clip(lower=0))

    # ---- T_RATE (абсолютная интенсивность) ----
    dur_s = (f["bidirectional_duration_ms"].astype(float) / 1000.0).clip(lower=1e-3)
    out["T_RATE__log_pkt_per_s"] = np.log1p(pk / dur_s)
    out["T_RATE__log_byte_per_s"] = np.log1p(by / dur_s)

    # ---- T_SHAPE (безразмерная форма времени) ----
    m = f["bidirectional_mean_piat_ms"].astype(float).clip(lower=0)
    s = f["bidirectional_stddev_piat_ms"].astype(float).clip(lower=0)
    mn = f["bidirectional_min_piat_ms"].astype(float).clip(lower=0)
    mx = f["bidirectional_max_piat_ms"].astype(float).clip(lower=0)
    ok = (m > EPS).astype(float)
    out["T_SHAPE__cv_piat"] = ok * np.log1p(s / np.maximum(m, EPS))
    out["T_SHAPE__log_max_over_mean"] = ok * np.log1p(mx / np.maximum(m, EPS))
    out["T_SHAPE__min_over_mean"] = ok * np.clip(mn / np.maximum(m, EPS), 0, 1)
    out["T_SHAPE__burstiness"] = _burstiness(m, s)
    ms = f["src2dst_mean_piat_ms"].astype(float).clip(lower=0)
    md = f["dst2src_mean_piat_ms"].astype(float).clip(lower=0)
    both = ((ms > EPS) & (md > EPS)).astype(float)
    out["T_SHAPE__dir_piat_logratio"] = both * np.clip(
        np.log((ms + EPS) / (md + EPS)), -10, 10)
    # доля длительности, приходящаяся на самый длинный интервал (безразмерно)
    d = f["bidirectional_duration_ms"].astype(float)
    out["T_SHAPE__max_gap_frac"] = np.where(d > EPS, np.clip(mx / np.maximum(d, EPS), 0, 1), 0.0)

    return out.replace([np.inf, -np.inf], 0).fillna(0).astype(np.float32)


def columns_for(feature_set: str, cols) -> list:
    groups = FEATURE_SETS[feature_set]
    return [c for c in cols if c.split("__")[0] in groups]


# ---------------------------------------------------------------------------
# Аналитическая (НЕ измеренная) ресурсная модель групп признаков на MCU.
# Считаем переменные состояния на один поток (float32/uint32 = 4 байта) и
# примерное число арифметических операций на пакет при онлайн-обновлении
# (Welford для среднего/дисперсии). Это оценка для сравнения групп между
# собой, а не замена измерению энергии на железе.
# ---------------------------------------------------------------------------
RESOURCE_SPEC = {
    # группа: (state_vars_per_flow, ops_per_packet, ops_at_flow_end, комментарий)
    "SIZE":    (17, 18, 12, "n, sum, M2, min, max размеров x3 направления + байты"),
    "FLAGS":   (6, 6, 6, "6 счётчиков флагов; протокол из заголовка"),
    "PORTS":   (0, 0, 4, "из 5-кортежа, состояние не нужно"),
    "T_RAW":   (19, 20, 8, "first/last ts, last ts по направлениям, IAT stats x3"),
    "T_RATE":  (2, 0, 4, "first/last ts (пакеты/байты уже есть в SIZE)"),
    "T_SHAPE": (0, 0, 10, "производные от статистик IAT группы T_RAW"),
}
# T_SHAPE требует IAT-статистик: если T_RAW не выбран, их состояние нужно всё равно.
SHAPE_NEEDS = "T_RAW"


def resource_estimate(feature_set: str) -> dict:
    groups = set(FEATURE_SETS[feature_set])
    need = set(groups)
    if "T_SHAPE" in groups:
        need.add(SHAPE_NEEDS)  # состояние IAT нужно, даже если признаки T_RAW не подаются
    if "T_RATE" in groups:
        need.add("SIZE")
    st = sum(RESOURCE_SPEC[g][0] for g in need)
    opp = sum(RESOURCE_SPEC[g][1] for g in need)
    ope = sum(RESOURCE_SPEC[g][2] for g in groups)
    return {"feature_set": feature_set, "state_bytes_per_flow": 4 * st,
            "ops_per_packet": opp, "ops_at_flow_end": ope}

"""Figures for the IEEE paper (vector PDF, IEEE column width)."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

D = os.path.join(os.path.dirname(__file__), "data")
F = os.path.join(os.path.dirname(__file__), "figs")
os.makedirs(F, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["DejaVu Serif"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.linewidth": 0.6,
    "lines.linewidth": 1.4, "lines.markersize": 4, "pdf.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": "#dddddd", "grid.linewidth": 0.5,
})
# Okabe-Ito (colour-blind safe) + distinct markers for redundancy
C = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9"]
M = ["o", "s", "^", "D", "v", "P"]
COL1, COL2 = 3.5, 7.16
NAMES = {"CICIoT2023": "CIC-IoT-2023", "EdgeIIoT": "Edge-IIoTset", "Gotham": "Gotham"}


def save(fig, name):
    fig.savefig(os.path.join(F, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(F, name + ".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def compact_ru():
    # E1: bars only
    t = pd.DataFrame({"model": ["DT", "MLP_S", "MLP_M", "CNN1D", "AE"],
                      "f1_in": [1.000, 0.998, 0.998, 0.994, 0.527],
                      "f1_cross": [0.796, 0.824, 0.815, 0.851, 0.152],
                      "lo": [0.669, 0.756, 0.722, 0.768, 0.092],
                      "hi": [0.903, 0.887, 0.894, 0.922, 0.213],
                      "i8": [np.nan, 0.833, 0.822, 0.818, 0.142]})
    fig, a = plt.subplots(figsize=(COL1, 1.75))
    x = np.arange(5)
    a.bar(x - 0.2, t.f1_in, 0.38, color="#BBBBBB", label="Внутри датасета (fp32)")
    a.bar(x + 0.2, t.f1_cross, 0.38, color=C[0], label="Перенос (fp32)")
    a.errorbar(x + 0.2, t.f1_cross, yerr=[t.f1_cross - t.lo, t.hi - t.f1_cross], fmt="none",
               ecolor="black", elinewidth=0.7, capsize=2)
    a.plot(x + 0.2, t.i8, "D", color=C[3], ms=3.5, label="Перенос (INT8)")
    a.set_xticks(x, t.model); a.set_ylim(0, 1.32); a.set_yticks([0, .2, .4, .6, .8, 1])
    a.set_ylabel("F1 при 10% атак"); a.grid(axis="x", visible=False)
    a.legend(loc="upper center", ncol=3, frameon=False, fontsize=6, handletextpad=0.3, columnspacing=0.6)
    fig.tight_layout(); save(fig, "ru_e1")
    # E3b: 3 small panels
    d = pd.read_csv(os.path.join(D, "A_means.csv"))
    srcs = [("CICIoT2023[host]", "CIC (хосты)"), ("Gotham[type]", "Gotham (типы)"), ("EdgeIIoT[file]", "Edge (сенсоры)")]
    fig, ax = plt.subplots(1, 3, figsize=(COL1, 1.55), sharey=True)
    for j, (s, tt) in enumerate(srcs):
        g = d[d.source == s]
        for i, k in enumerate(sorted(g.k.unique())):
            gk = g[g.k == k].sort_values("V")
            ax[j].plot(gk.V, gk.false_alarm, "-" + M[i], color=C[i], ms=2.5, lw=1.1, label=f"k={k}")
        ax[j].set_xscale("log", base=2); ax[j].set_xticks([250, 500, 1000, 2000], ["250", "", "1k", "2k"])
        ax[j].minorticks_off(); ax[j].set_title(tt, fontsize=6.5); ax[j].tick_params(labelsize=6)
    ax[1].set_xlabel("Нормальных потоков $V$", fontsize=7)
    ax[0].set_ylabel("Ложные тревоги", fontsize=7); ax[0].set_ylim(0, 0.42)
    h, l = ax[0].get_legend_handles_labels()
    fig.tight_layout(w_pad=0.3, rect=(0, 0.06, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=4, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.03))
    save(fig, "ru_e3b")
    # E4: false alarms only
    b = pd.read_csv(os.path.join(D, "B_means.csv")); b = b[b.model == "MLP_S"]
    pairs = [("EdgeIIoT", "CICIoT2023"), ("EdgeIIoT", "Gotham"), ("Gotham", "CICIoT2023"), ("Gotham", "EdgeIIoT")]
    short = {"CICIoT2023": "CIC", "EdgeIIoT": "Edge", "Gotham": "Gotham"}
    fig, a = plt.subplots(figsize=(COL1, 1.55))
    for i, (s, t2) in enumerate(pairs):
        g = b[(b.source == s) & (b.target == t2)].sort_values("k_t")
        a.plot(g.k_t, g.false_alarm, "-" + M[i], color=C[i], ms=3, label=f"{short[s]}→{short[t2]}")
    a.set_xticks([0, 1, 2, 4, 8]); a.set_xlabel("Устройств целевой сети $k_t$")
    a.set_ylabel("Ложные тревоги"); a.legend(frameon=False, fontsize=6, ncol=2)
    fig.tight_layout(); save(fig, "ru_e4")
    # E3: compact 4 panels, full width but short
    dd = pd.read_csv(os.path.join(D, "diversity_results.csv")); dd = dd[dd.eval_on != "source"]
    m = dd.groupby(["experiment", "eval_on", "model", "k"])["false_alarm"].mean().reset_index()
    exps = [("CICIoT2023[host]", "(a) CIC, 53 хоста"), ("Gotham[file]", "(b) Gotham, 78 устройств"),
            ("Gotham[type]", "(c) Gotham, 12 типов"), ("EdgeIIoT[file]", "(d) Edge, 5 сенсоров")]
    fig, ax = plt.subplots(1, 4, figsize=(COL2, 1.45), sharey=True)
    for j, (e, tt) in enumerate(exps):
        g = m[m.experiment == e]
        for (t2, mdl), gg in g.groupby(["eval_on", "model"]):
            gg = gg.sort_values("k")
            ax[j].plot(gg.k, gg.false_alarm, "-o" if mdl == "MLP_S" else "--s", ms=2.5, lw=1.1,
                       color=C[[*NAMES].index(t2)])
        ks = [k for k in sorted(g.k.unique()) if k != 64]
        ax[j].set_xscale("log", base=2); ax[j].set_xticks(ks, [str(k) for k in ks]); ax[j].minorticks_off()
        ax[j].tick_params(labelsize=6); ax[j].set_title(tt, loc="left", fontsize=7)
        ax[j].set_xlabel("Групп нормы $k$", fontsize=7)
    ax[0].set_ylabel("Ложные тревоги", fontsize=7)
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=C[0], lw=2, label="Цель CIC-IoT-2023"),
         Line2D([], [], color=C[1], lw=2, label="Цель Edge-IIoTset"),
         Line2D([], [], color=C[2], lw=2, label="Цель Gotham"),
         Line2D([], [], color="k", ls="-", marker="o", ms=3, label="MLP_S"),
         Line2D([], [], color="k", ls="--", marker="s", ms=3, label="DT")]
    fig.tight_layout(w_pad=0.3, rect=(0, 0, 0.85, 1))
    fig.legend(handles=h, loc="center left", frameon=False, fontsize=6, bbox_to_anchor=(0.85, 0.55))
    save(fig, "ru_e3")


compact_ru()

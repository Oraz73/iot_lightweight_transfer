"""Regenerates all paper figures from the CSV files in ../results.

E1 values are the aggregated outputs of src/v6_analyze.py (T1/T3), copied here verbatim."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

R = os.path.join(os.path.dirname(__file__), "..", "results")
F = os.path.join(os.path.dirname(__file__), "figs")
os.makedirs(F, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.linewidth": 0.6,
    "lines.linewidth": 1.4, "lines.markersize": 4, "pdf.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": "#dddddd", "grid.linewidth": 0.5,
})
# Okabe-Ito (colour-blind safe) + distinct markers for redundancy
C = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9"]
M = ["o", "s", "^", "D", "v", "P"]
COL1, COL2 = 3.5, 7.16
NAMES = {"CICIoT2023": "CIC-IoT-2023", "EdgeIIoT": "Edge-IIoTset", "Gotham": "Gotham"}


def save(fig, name):
    fig.savefig(os.path.join(F, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(F, name + ".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- E1
def fig_e1():
    # aggregated results of v6_analyze (T1, T3); cross-network n = 18
    t = pd.DataFrame({
        "model": ["DT", "MLP_S", "MLP_M", "CNN1D", "AE"],
        "f1_in": [1.000, 0.998, 0.998, 0.994, 0.527],
        "f1_cross": [0.796, 0.824, 0.815, 0.851, 0.152],
        "lo": [0.669, 0.756, 0.722, 0.768, 0.092],
        "hi": [0.903, 0.887, 0.894, 0.922, 0.213],
        "f1_cross_int8": [np.nan, 0.833, 0.822, 0.818, 0.142],
        "kb32": [1.45, 4.04, 15.86, 6.78, 5.70],
        "kb8": [np.nan, 3.55, 8.41, 6.63, 5.04],
    })
    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.3), gridspec_kw={"width_ratios": [1.25, 1]})
    x = np.arange(len(t))
    a = ax[0]
    a.bar(x - 0.2, t.f1_in, 0.38, color="#BBBBBB", label="In-domain (fp32)")
    a.bar(x + 0.2, t.f1_cross, 0.38, color=C[0], label="Cross-network (fp32)")
    a.errorbar(x + 0.2, t.f1_cross, yerr=[t.f1_cross - t.lo, t.hi - t.f1_cross],
               fmt="none", ecolor="black", elinewidth=0.7, capsize=2)
    a.plot(x + 0.2, t.f1_cross_int8, "D", color=C[3], ms=4, label="Cross-network (INT8)")
    a.set_xticks(x, t.model)
    a.set_ylim(0, 1.3)
    a.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    a.set_ylabel("F1 at 10% attack prevalence")
    a.set_title("(a) In-domain vs. cross-network F1", loc="left")
    a.legend(loc="upper center", frameon=False, ncol=3, fontsize=6.5, handletextpad=0.4, columnspacing=0.8)
    a.grid(axis="x", visible=False)
    b = ax[1]
    for i, r in t.iterrows():
        b.plot(r.kb32, r.f1_cross, M[i], color=C[i], ms=6, mec="white", mew=0.6, label=r.model)
        if not np.isnan(r.kb8):
            b.plot(r.kb8, r.f1_cross_int8, M[i], color=C[i], ms=6, mfc="white", mew=1.0)
            b.annotate("", (r.kb8, r.f1_cross_int8), (r.kb32, r.f1_cross),
                       arrowprops=dict(arrowstyle="->", color=C[i], lw=0.6))
    b.set_xscale("log")
    from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
    b.xaxis.set_major_locator(FixedLocator([1, 2, 4, 8, 16]))
    b.xaxis.set_major_formatter(FixedFormatter(["1", "2", "4", "8", "16"]))
    b.xaxis.set_minor_locator(NullLocator())
    b.set_xlabel("Model size, KB (log; filled = fp32, hollow = INT8)")
    b.set_ylabel("Cross-network F1")
    b.set_title("(b) Size vs. cross-network F1", loc="left")
    b.legend(frameon=False, ncol=1, loc="center right")
    fig.tight_layout(w_pad=1.5)
    save(fig, "fig_e1_models")


# ---------------------------------------------------------------- E3b
def fig_e3b():
    a = pd.read_csv(os.path.join(R, "E3b_E4_controls", "A_means.csv"))
    srcs = [("CICIoT2023[host]", "CIC-IoT-2023 (hosts)"),
            ("Gotham[type]", "Gotham (device types)"),
            ("EdgeIIoT[file]", "Edge-IIoTset (sensors)")]
    fig, ax = plt.subplots(1, 3, figsize=(COL2, 2.1), sharey=True)
    for j, (s, title) in enumerate(srcs):
        g = a[a.source == s]
        for i, k in enumerate(sorted(g.k.unique())):
            gk = g[g.k == k].sort_values("V")
            ax[j].plot(gk.V, gk.false_alarm, "-" + M[i], color=C[i], label=f"$k$ = {k}")
        ax[j].set_xscale("log", base=2)
        ax[j].set_xticks([250, 500, 1000, 2000], ["250", "500", "1000", "2000"])
        ax[j].minorticks_off()
        ax[j].set_title(f"({'abc'[j]}) {title}", loc="left")
        ax[j].set_xlabel("Benign training flows $V$")
    ax[0].set_ylabel("Cross-network false-alarm rate")
    ax[0].set_ylim(0, 0.42)
    ax[1].legend(frameon=False, title="Benign groups", title_fontsize=7)
    fig.tight_layout(w_pad=0.8)
    save(fig, "fig_e3b_volume_diversity")


# ---------------------------------------------------------------- E4
def fig_e4():
    b = pd.read_csv(os.path.join(R, "E3b_E4_controls", "B_means.csv"))
    b = b[b.model == "MLP_S"]
    pairs = [("EdgeIIoT", "CICIoT2023"), ("EdgeIIoT", "Gotham"), ("Gotham", "CICIoT2023"),
             ("Gotham", "EdgeIIoT"), ("CICIoT2023", "Gotham"), ("CICIoT2023", "EdgeIIoT")]
    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.2))
    for i, (s, t) in enumerate(pairs):
        g = b[(b.source == s) & (b.target == t)].sort_values("k_t")
        lab = f"{NAMES[s]} → {NAMES[t]}"
        ax[0].plot(g.k_t, g.false_alarm, "-" + M[i], color=C[i], label=lab)
        ax[1].plot(g.k_t, g.detection, "-" + M[i], color=C[i], label=lab)
    for j, (yl, tt) in enumerate([("False-alarm rate (held-out devices)", "(a) False alarms"),
                                  ("Detection rate (target attacks)", "(b) Detection")]):
        ax[j].set_xticks([0, 1, 2, 4, 8])
        ax[j].set_xlabel("Target devices used for adaptation $k_t$")
        ax[j].set_ylabel(yl)
        ax[j].set_title(tt + " (MLP_S)", loc="left")
    ax[1].set_ylim(0, 1.05)
    ax[0].legend(frameon=False, fontsize=6.5)
    fig.tight_layout(w_pad=1.5)
    save(fig, "fig_e4_adaptation")


# ---------------------------------------------------------------- E3 (needs diversity_results.csv)
def fig_e3():
    p = os.path.join(R, "E3_diversity", "diversity_results.csv")
    if not os.path.exists(p):
        print("diversity_results.csv missing: E3 figure skipped")
        return
    d = pd.read_csv(p)
    d = d[d.eval_on != "source"]
    m = d.groupby(["experiment", "eval_on", "model", "k"])["false_alarm"].mean().reset_index()
    exps = [("CICIoT2023[host]", "CIC-IoT-2023 (53 hosts)"), ("Gotham[file]", "Gotham (78 devices)"),
            ("Gotham[type]", "Gotham (12 device types)"), ("EdgeIIoT[file]", "Edge-IIoTset (5 sensors)")]
    fig, ax = plt.subplots(1, 4, figsize=(COL2, 2.0), sharey=True)
    for j, (e, title) in enumerate(exps):
        g = m[m.experiment == e]
        for i, ((t, mdl), gg) in enumerate(g.groupby(["eval_on", "model"])):
            gg = gg.sort_values("k")
            ax[j].plot(gg.k, gg.false_alarm, ("-o" if mdl == "MLP_S" else "--s"),
                       color=C[[*NAMES].index(t) if t in NAMES else 0],
                       label=f"{mdl} → {NAMES.get(t, t)}")
        ax[j].set_xscale("log", base=2)
        ks = [k for k in sorted(g.k.unique()) if k != 64]
        ax[j].set_xticks(ks, [str(k) for k in ks])
        ax[j].minorticks_off()
        ax[j].tick_params(axis="x", labelsize=6)
        ax[j].set_title(f"({'abcd'[j]}) {title}", loc="left", fontsize=7)
        ax[j].set_xlabel("Benign groups $k$")
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=C[0], lw=2, label="Target: CIC-IoT-2023"),
         Line2D([], [], color=C[1], lw=2, label="Target: Edge-IIoTset"),
         Line2D([], [], color=C[2], lw=2, label="Target: Gotham"),
         Line2D([], [], color="black", ls="-", marker="o", label="MLP_S"),
         Line2D([], [], color="black", ls="--", marker="s", label="DT")]
    ax[0].set_ylabel("Cross-network false-alarm rate")
    fig.tight_layout(w_pad=0.5, rect=(0, 0.08, 1, 1))
    fig.legend(handles=h, loc="lower center", ncol=5, frameon=False, fontsize=7, bbox_to_anchor=(0.5, -0.02))
    save(fig, "fig_e3_diversity")


if __name__ == "__main__":
    fig_e1(); fig_e3b(); fig_e4(); fig_e3()
    print(sorted(os.listdir(F)))


# ---------------------------------------------------------------- compact single-column variants
def compact():
    # E1: bars only
    t = pd.DataFrame({"model": ["DT", "MLP_S", "MLP_M", "CNN1D", "AE"],
                      "f1_in": [1.000, 0.998, 0.998, 0.994, 0.527],
                      "f1_cross": [0.796, 0.824, 0.815, 0.851, 0.152],
                      "lo": [0.669, 0.756, 0.722, 0.768, 0.092],
                      "hi": [0.903, 0.887, 0.894, 0.922, 0.213],
                      "i8": [np.nan, 0.833, 0.822, 0.818, 0.142]})
    fig, a = plt.subplots(figsize=(COL1, 1.75))
    x = np.arange(5)
    a.bar(x - 0.2, t.f1_in, 0.38, color="#BBBBBB", label="In-domain (fp32)")
    a.bar(x + 0.2, t.f1_cross, 0.38, color=C[0], label="Cross-network (fp32)")
    a.errorbar(x + 0.2, t.f1_cross, yerr=[t.f1_cross - t.lo, t.hi - t.f1_cross], fmt="none",
               ecolor="black", elinewidth=0.7, capsize=2)
    a.plot(x + 0.2, t.i8, "D", color=C[3], ms=3.5, label="Cross-network (INT8)")
    a.set_xticks(x, t.model); a.set_ylim(0, 1.32); a.set_yticks([0, .2, .4, .6, .8, 1])
    a.set_ylabel("F1 at 10% prevalence"); a.grid(axis="x", visible=False)
    a.legend(loc="upper center", ncol=3, frameon=False, fontsize=6, handletextpad=0.3, columnspacing=0.6)
    fig.tight_layout(); save(fig, "c_e1")
    # E3b: 3 small panels
    d = pd.read_csv(os.path.join(R, "E3b_E4_controls", "A_means.csv"))
    srcs = [("CICIoT2023[host]", "CIC (hosts)"), ("Gotham[type]", "Gotham (types)"), ("EdgeIIoT[file]", "Edge (sensors)")]
    fig, ax = plt.subplots(1, 3, figsize=(COL1, 1.55), sharey=True)
    for j, (s, tt) in enumerate(srcs):
        g = d[d.source == s]
        for i, k in enumerate(sorted(g.k.unique())):
            gk = g[g.k == k].sort_values("V")
            ax[j].plot(gk.V, gk.false_alarm, "-" + M[i], color=C[i], ms=2.5, lw=1.1, label=f"k={k}")
        ax[j].set_xscale("log", base=2); ax[j].set_xticks([250, 500, 1000, 2000], ["250", "", "1k", "2k"])
        ax[j].minorticks_off(); ax[j].set_title(tt, fontsize=6.5); ax[j].tick_params(labelsize=6)
    ax[1].set_xlabel("Benign training flows $V$", fontsize=7)
    ax[0].set_ylabel("Cross FA rate", fontsize=7); ax[0].set_ylim(0, 0.42)
    h, l = ax[0].get_legend_handles_labels()
    fig.tight_layout(w_pad=0.3, rect=(0, 0.06, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=4, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.03))
    save(fig, "c_e3b")
    # E4: false alarms only
    b = pd.read_csv(os.path.join(R, "E3b_E4_controls", "B_means.csv")); b = b[b.model == "MLP_S"]
    pairs = [("EdgeIIoT", "CICIoT2023"), ("EdgeIIoT", "Gotham"), ("Gotham", "CICIoT2023"), ("Gotham", "EdgeIIoT")]
    short = {"CICIoT2023": "CIC", "EdgeIIoT": "Edge", "Gotham": "Gotham"}
    fig, a = plt.subplots(figsize=(COL1, 1.55))
    for i, (s, t2) in enumerate(pairs):
        g = b[(b.source == s) & (b.target == t2)].sort_values("k_t")
        a.plot(g.k_t, g.false_alarm, "-" + M[i], color=C[i], ms=3, label=f"{short[s]}→{short[t2]}")
    a.set_xticks([0, 1, 2, 4, 8]); a.set_xlabel("Target devices used for adaptation $k_t$")
    a.set_ylabel("FA on held-out devices"); a.legend(frameon=False, fontsize=6, ncol=2)
    fig.tight_layout(); save(fig, "c_e4")
    # E3: compact 4 panels, full width but short
    dd = pd.read_csv(os.path.join(R, "E3_diversity", "diversity_results.csv")); dd = dd[dd.eval_on != "source"]
    m = dd.groupby(["experiment", "eval_on", "model", "k"])["false_alarm"].mean().reset_index()
    exps = [("CICIoT2023[host]", "(a) CIC, 53 hosts"), ("Gotham[file]", "(b) Gotham, 78 devices"),
            ("Gotham[type]", "(c) Gotham, 12 types"), ("EdgeIIoT[file]", "(d) Edge, 5 sensors")]
    fig, ax = plt.subplots(1, 4, figsize=(COL2, 1.45), sharey=True)
    for j, (e, tt) in enumerate(exps):
        g = m[m.experiment == e]
        for (t2, mdl), gg in g.groupby(["eval_on", "model"]):
            gg = gg.sort_values("k")
            ax[j].plot(gg.k, gg.false_alarm, "-o" if mdl == "MLP_S" else "--s", ms=2.5, lw=1.1,
                       color=C[[*NAMES].index(t2)])
        ks = [k for k in sorted(g.k.unique()) if k != 64]
        ax[j].set_xscale("log", base=2); ax[j].set_xticks(ks, [str(k) for k in ks]); ax[j].minorticks_off()
        ax[j].tick_params(labelsize=6); ax[j].set_title(tt, loc="left", fontsize=7)
        ax[j].set_xlabel("Benign groups $k$", fontsize=7)
    ax[0].set_ylabel("Cross FA rate", fontsize=7)
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=C[0], lw=2, label="Target CIC-IoT-2023"),
         Line2D([], [], color=C[1], lw=2, label="Target Edge-IIoTset"),
         Line2D([], [], color=C[2], lw=2, label="Target Gotham"),
         Line2D([], [], color="k", ls="-", marker="o", ms=3, label="MLP_S"),
         Line2D([], [], color="k", ls="--", marker="s", ms=3, label="DT")]
    fig.tight_layout(w_pad=0.3, rect=(0, 0, 0.85, 1))
    fig.legend(handles=h, loc="center left", frameon=False, fontsize=6, bbox_to_anchor=(0.85, 0.55))
    save(fig, "c_e3")


compact()
